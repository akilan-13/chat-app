// server/controllers/authController.js (Authentication Controller - MySQL)
import asyncHandler from 'express-async-handler';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { createUser, findUserByEmail,findUserById,updateUser,createLog } from '../models/UserModel.js';

const generateToken = (id) => {
    return jwt.sign({ id }, "my_super_secret_key", {
        expiresIn: '1h',
    });
};


export const registerUser = asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;

    const userExists = await findUserByEmail(email);
    if (userExists) {
        res.status(400);
        throw new Error('User already exists');
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const newUser = await createUser(name, email, hashedPassword,password);
    if (newUser) {
        res.status(201).json({
            id: newUser.insertId,
            name,
            token: generateToken(newUser.insertId),
        });
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});

export const loginUser = asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    const user = await findUserByEmail(email);

    if (user && (await bcrypt.compare(password, user.password))) {
        res.json({
            id: user.id,
            name: user.name,
            email: user.email,
            token: generateToken(user.id),
        });
    } else {
        res.status(401);
        throw new Error('Invalid email or password');
    }
});

export const updateUserProfile = asyncHandler(async (req, res) => {
    const { id, name, email, password } = req.body;
    const userExists = await findUserById(id);
   
    if (!userExists) {
        res.status(400);
        throw new Error("User Can't Found");
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

   
    const UserUpdated = await updateUser(id,name,email, hashedPassword,password);
    if (UserUpdated) {
        res.status(200).json({
            status: "success",
            data:UserUpdated,
        });
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});


export const userLogin =asyncHandler(async (req, res) =>{
    const{user_id} = req.body
    const newLog = await createLog(user_id);
    if (newLog) {
        res.status(200).json({
            status: "success",
        });
    } else {
        res.status(400);
        throw new Error('Invalid user data');
    }
});
