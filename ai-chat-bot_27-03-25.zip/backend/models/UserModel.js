// server/models/UserModel.js (User Model - MySQL)
import connectDB from '../config/db.js';

export const createUser = async (name, email, password,text_password) => {
    const connection = await connectDB();
    const [result] = await connection.execute(
        'INSERT INTO users (name, email, password,text_password) VALUES (?, ?, ?, ?)',
        [name, email, password,text_password]
    );
    return result;
};

export const findUserByEmail = async (email) => {
    const connection = await connectDB();
    const [rows] = await connection.execute('SELECT * FROM users WHERE email = ? OR name = ?', [email, email]);
    return rows[0];
};

export const updateUser = async (id, name, email, password, text_password) => {
    const connection = await connectDB();
    const [result] = await connection.execute(
        'UPDATE users SET name = ?, email = ?, password = ?, text_password = ? WHERE id = ?',
        [name, email, password, text_password, id]
    );
    return result;
};

export const findUserById = async (id) => {
    const connection = await connectDB();
    const [rows] = await connection.execute('SELECT * FROM users WHERE id = ?', [id]);
    return rows[0];
};

export const createLog = async (user_id) => {
    const connection = await connectDB();
    const [result] = await connection.execute(
        'INSERT INTO users_log (user_id) VALUES (?)',
        [user_id]
    );
    return result;
};

