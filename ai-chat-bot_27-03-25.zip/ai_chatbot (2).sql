-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2025 at 02:21 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ai_chatbot`
--

-- --------------------------------------------------------

--
-- Table structure for table `ai_fallback_logs`
--

CREATE TABLE `ai_fallback_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `input_message` text NOT NULL,
  `fallback_response` text NOT NULL,
  `used_model` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ai_responses`
--

CREATE TABLE `ai_responses` (
  `id` int(11) NOT NULL,
  `input_message` text NOT NULL,
  `ai_response` text NOT NULL,
  `model_used` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sender` enum('user','bot') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `user_id`, `message`, `sender`, `created_at`) VALUES
(181, 6, 'hi', 'user', '2025-03-15 13:04:00'),
(182, 6, 'How\'s it going? Is there something I can help you with or would you like to chat?', 'bot', '2025-03-15 13:04:03'),
(183, 6, ' hello', 'user', '2025-03-15 13:05:50'),
(184, 6, 'Hello! How are you doing today? Is there something I can help you with or would you like to chat?', 'bot', '2025-03-15 13:05:54'),
(185, 6, 'tell me story', 'user', '2025-03-15 13:06:11'),
(186, 6, 'Once upon a time, in a small village nestled in the rolling hills of a far-off land, there lived a young girl named Luna. Luna was a curious and adventurous soul, with a mop of curly brown hair and a smile that could light up the darkest of rooms.\n\nOne day, while wandering through the village market, Luna stumbled upon a small, mysterious shop tucked away between a baker\'s and a blacksmith\'s. The sign above the door read \"Curios and Wonders,\" and the windows were filled with a dazzling array of strange and exotic objects.\n\nLuna\'s curiosity was piqued, and she pushed open the door to reveal a dimly lit interior filled with an incredible assortment of treasures. There were vintage clocks, rare books, and even a taxidermied owl perched on a shelf, watching her with wise, glassy eyes.\n\nBehind the counter, a bespectacled old man with a kind face and a wild shock of white hair looked up from the', 'bot', '2025-03-15 13:06:16'),
(187, 6, 'python error facing how to url call in view.py', 'user', '2025-03-15 13:06:54'),
(188, 6, 'You\'re facing an error when making a URL call in your `view.py` file in a Python project, likely using a web framework like Django. There are several potential issues that could be causing this error. Let\'s go through some common solutions:\n\n1. **Typo in URL Configuration**: Ensure that your URL configuration in `urls.py` is correct and matches the path you\'re calling in `view.py`. A small typo in the URL pattern can cause a `404 Not Found` error.\n\n2. **Missing app_name in URL Configuration**: If you\'re using Django, remember to include `app_name` in your `urls.py` file for each app, especially when using include() to include other URL configurations.\n\n3. **Incorrect URL Pattern**: Make sure the URL pattern in `urls.py` matches the path you\'re trying to access. URLs are case-sensitive, so ensure that the path you\'re calling matches the exact pattern in your URL configuration.\n\n4. **View Function Name**:', 'bot', '2025-03-15 13:06:58'),
(189, 7, 'Hi I am Your Integrate Developer for this App', 'user', '2025-03-18 11:57:45'),
(190, 7, 'Welcome! I\'m excited to work with you as your Integrated Developer for this App. What\'s the current status of the project, and what\'s the first task or issue you\'d like to tackle together?', 'bot', '2025-03-18 11:57:47'),
(191, 7, 'why Could You Store My Name ?', 'user', '2025-03-18 11:59:00'),
(192, 7, 'I don\'t store your name or any personal data. I\'m a large language model, I don\'t have the capability to store or retain any information about our conversation, including your name.\n\nEach time you interact with me, it\'s a new conversation, and I don\'t retain any context or information from previous conversations. I\'m designed to process and respond to text-based input in real-time, without storing any personal data.\n\nIf you\'d like to keep your identity private, you can always refer to yourself as a pseudonym or a generic term, and I\'ll respond accordingly.', 'bot', '2025-03-18 11:59:03'),
(193, 7, 'So What Can i do for save Conversation like another gpt', 'user', '2025-03-18 12:00:00'),
(194, 7, 'You want to know how to improve or \"save\" a conversation, much like how large language models like myself can generate coherent and engaging text. Here are some strategies to help you keep a conversation flowing:\n\n1. **Active listening**: Pay attention to what the other person is saying, both verbally and non-verbally. This will help you respond thoughtfully and show that you\'re genuinely interested in the conversation.\n2. **Ask open-ended questions**: Encourage the other person to share more by asking questions that can\'t be answered with a simple \"yes\" or \"no.\" This will help keep the conversation flowing and allow you to learn more about the other person.\n3. **Show genuine interest**: People are more likely to engage in a conversation if they feel like you\'re genuinely interested in what they have to say. Ask follow-up questions, show enthusiasm, and acknowledge their thoughts and feelings.\n4. **Find common ground**: Look for shared interests, experiences, or values that can help', 'bot', '2025-03-18 12:00:03'),
(195, 7, 'my name is Akmax ,Your name is MaxBot', 'user', '2025-03-18 12:02:46'),
(196, 7, 'Nice to meet you, Akmax! I\'m MaxBot, your friendly AI companion. What\'s on your mind today? Want to chat about something in particular or just shoot the breeze? I\'m all ears (or rather, all text)!', 'bot', '2025-03-18 12:02:49'),
(197, 7, 'what is my name', 'user', '2025-03-18 12:03:13'),
(198, 7, 'I don\'t have any information about your name. This is the beginning of our conversation, and I don\'t retain any information about individual users. If you\'d like to share your name with me, I\'d be happy to chat with you!', 'bot', '2025-03-18 12:03:15'),
(199, 7, 'Generate a list of skill tags for a job category Developer and role Junior Java Developer.', 'user', '2025-03-25 05:30:30'),
(200, 7, 'Here is a list of skill tags that can be relevant for a Junior Java Developer:\n\n**Programming Languages:**\n\n* Java\n* Java 8/11/17\n* Java EE\n* Java Spring\n* Java Hibernate\n* Java Maven\n* Java Gradle\n* Java IntelliJ IDEA\n* Java Eclipse\n\n**Development Skills:**\n\n* Object-Oriented Programming (OOP)\n* Design Patterns (e.g. Singleton, Factory, Observer)\n* Algorithms and Data Structures (e.g. Arrays, Linked Lists, Trees)\n* Database Systems (e.g. MySQL, PostgreSQL)\n* SQL\n* NoSQL databases (e.g. MongoDB, Cassandra)\n* Cloud Computing (e.g. AWS, Azure, Google Cloud)\n* Microservices Architecture\n* RESTful APIs\n* API Design\n\n**Technologies:**\n\n* Spring Boot\n* Spring Framework\n* Hibernate\n* JPA\n* JavaFX\n* Java Swing\n* Maven\n* Gradle\n* Jenkins (', 'bot', '2025-03-25 05:30:35'),
(201, 8, 'hello', 'user', '2025-03-26 12:17:54'),
(202, 8, 'Hello! How can I assist you today?', 'bot', '2025-03-26 12:17:56'),
(203, 8, 'hi\\', 'user', '2025-03-26 12:18:22'),
(204, 8, 'It seems like you just wanted to say \"hi\". How can I assist you today?', 'bot', '2025-03-26 12:18:23'),
(205, 8, 'i am vasanth Developer TL In IT Company what can i do for improve my career life', 'user', '2025-03-26 12:20:09'),
(206, 8, 'As a Developer Team Lead (TL) in an IT company, you have a strong foundation in technical skills and have already taken on leadership responsibilities. To improve your career life, consider the following suggestions:\n\n1. **Develop Soft Skills**:\n	* Improve communication and interpersonal skills to effectively manage teams, stakeholders, and clients.\n	* Enhance your leadership skills by learning from mentors, reading books, or taking online courses.\n	* Develop conflict resolution and negotiation skills to resolve issues and close deals.\n2. **Upskill and Reskill**:\n	* Stay updated on the latest technologies, frameworks, and tools used in your domain.\n	* Explore adjacent areas, such as DevOps, cloud computing, or machine learning, to broaden your expertise.\n	* Consider certifications like AWS, Azure, or Google Cloud to demonstrate your expertise.\n3. **Take on Additional Responsibilities**:\n	* Volunteer for high-visibility projects or initiatives that demonstrate your capabilities to stakeholders.\n	* Offer to mentor junior', 'bot', '2025-03-26 12:20:13'),
(207, 8, 'hiii', 'user', '2025-03-26 12:25:34'),
(208, 8, 'Hiii! How\'s your day going so far?', 'bot', '2025-03-26 12:25:36'),
(209, 8, 'good morning', 'user', '2025-03-26 12:26:26'),
(210, 8, 'Good morning! How can I help you today?', 'bot', '2025-03-26 12:26:27');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `general_settings_id` int(11) NOT NULL,
  `logo` text DEFAULT NULL,
  `fav_icon` text DEFAULT NULL,
  `title` text NOT NULL,
  `date_format` varchar(20) DEFAULT NULL,
  `email` text DEFAULT NULL,
  `website` text DEFAULT NULL,
  `phone_no` varchar(11) DEFAULT NULL,
  `mobile_no` varchar(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `area_street` text DEFAULT NULL,
  `pincode` text DEFAULT NULL,
  `auto_logout_time_admin` int(11) DEFAULT NULL COMMENT '(in mins)',
  `auto_logout_time_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`general_settings_id`, `logo`, `fav_icon`, `title`, `date_format`, `email`, `website`, `phone_no`, `mobile_no`, `country_id`, `state_id`, `city_id`, `area_street`, `pincode`, `auto_logout_time_admin`, `auto_logout_time_user`) VALUES
(1, '', 'ai_chat_bot_icon.png', 'AI-ChatBot', 'd/M/Y', '', '', '', '', 101, 35, 3912, 'Anna nagar', '623704', 360, 360);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `is_ai` tinyint(1) DEFAULT 0,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `text_password` varchar(250) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `text_password`, `created_at`) VALUES
(6, 'Rakesh', 'rakesh123@gmail.com', '$2b$10$qlC4Zg5iPPouOLRylFUwXux2YMb.dDvdv91wQcpKvLA2ObLFtR3Li', 'Rakesh', '2025-03-15 13:02:49'),
(7, 'akmax', 'akmax123@gmail.com', '$2b$10$bGlDIZni04nkRRBlcEZrKe2nOyCXsbdGBXrbOC1vRknogl6h9b0ya', 'akmax@007', '2025-03-17 12:21:44'),
(8, 'vasanth', 'vasanth123@gmail.com', '$2b$10$uFZbKnuLi.bHpDpYgkdGRuXUOwK8Gh4HE5UHnMmPZXfMJZUz4oBCW', 'vasanth', '2025-03-26 12:17:10');

-- --------------------------------------------------------

--
-- Table structure for table `users_log`
--

CREATE TABLE `users_log` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `login_time` datetime NOT NULL DEFAULT current_timestamp(),
  `logout_time` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users_old`
--

CREATE TABLE `users_old` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `text_password` tinytext DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_old`
--

INSERT INTO `users_old` (`id`, `username`, `email`, `password`, `created_at`, `text_password`, `status`) VALUES
(1, 'akmax', 'akmax@gmail.com', '$2b$10$XXjAPmJc2GG8Q2lC9wzsEu4bA5/g9Hj/VMCo5jzJRWolWDBHy7hAy', '2025-02-19 12:53:06', 'akmax@007', 0),
(2, 'akil_45', 'akmax45@gmail.com', '$2b$10$pgMD8qxLfqmKDQgDfe1GYOgOeCs1azKirMteexDwwMRQxWwpZHMsW', '2025-02-19 12:54:09', 'akmax007', 0),
(7, 'akil_55', 'akmax55@gmail.com', '$2b$10$sQRuYmIU2PSo1ob6pMwO6uJRgUG9qtBaZq7DlYqkcD6uqXImb4zk6', '2025-02-19 13:02:36', 'akmax007', 0),
(9, 'akmax_7', 'akmax7@gmail.com', '$2b$10$KUkI.kniCm9Cm2WTJarS3eok7ucEPBenWQToMZnixjQFiZe6gNgdK', '2025-02-19 13:03:48', 'akmax@007', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ai_fallback_logs`
--
ALTER TABLE `ai_fallback_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `ai_responses`
--
ALTER TABLE `ai_responses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`general_settings_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users_log`
--
ALTER TABLE `users_log`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`user_id`);

--
-- Indexes for table `users_old`
--
ALTER TABLE `users_old`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ai_fallback_logs`
--
ALTER TABLE `ai_fallback_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ai_responses`
--
ALTER TABLE `ai_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `general_settings_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users_log`
--
ALTER TABLE `users_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_old`
--
ALTER TABLE `users_old`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ai_fallback_logs`
--
ALTER TABLE `ai_fallback_logs`
  ADD CONSTRAINT `ai_fallback_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_old` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users_old` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `users_log`
--
ALTER TABLE `users_log`
  ADD CONSTRAINT `users_log_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
