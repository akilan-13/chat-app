import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { getToken } from '../services/api';  // Ensure it fetches token from localStorage

const PrivateRoute = () => {
    const token = getToken();  // Check if user is logged in

    return token ? <Outlet /> : <Navigate to="/login" />;
};

export default PrivateRoute;
