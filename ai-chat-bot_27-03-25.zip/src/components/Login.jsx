import { Link } from "react-router-dom";

const Login =({handleLogin,setPassword,setUsername,username,password,handleSignupPage,loginPage,signPage})=> {

  return (
    <>
    <div className="w-full h-screen fixed flex items-center justify-center ">
      <div className="flex flex-col items-center justify-center  bg-gray-100">
        <div className="w-96 bg-white shadow-lg rounded-lg p-6">
          <h2 className="text-2xl font-bold text-center mb-4">Login</h2>
          <form onSubmit={handleLogin} className="flex flex-col">
            <input
              type="text"
              placeholder="Username"
              className="border px-3 py-2 mb-3 rounded"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Password"
              className="border px-3 py-2 mb-3 rounded"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
            <button type="submit" className="bg-[#d6358e] text-white py-2 rounded">
              Login
            </button>
          </form>
          <p className="text-center mt-4">
            If You Dont't have an account?{" "}
            <span onClick={handleSignupPage}><Link to="/signup" className="text-blue-500">signup here</Link></span>
          </p>
        </div>
      </div>
    </div>
    
    </>
  );
}

export default Login;
