import './loader.css';

const PageLoader =()=> {
return (<>
    <div className='w-full h-screen absolute top-0 left-0 z-[1000000] bg-gray-600 bg-opacity-70'>
        <div className='w-full h-full flex justify-center items-center'>
        <span className="loader"></span>
        </div>
    </div>
</>);
}


export default PageLoader;