// client/src/components/ChatBox.js (Chat UI Component)
import React, { useState, useEffect ,useRef} from 'react';
import socket from '../services/socket';
import axios from 'axios';
import './ChatBox.css';
import { useNavigate } from 'react-router-dom';
import { getUserData,logoutUser ,updateUserProfile,getToken} from '../services/api';
import Loader from './Loader';
import {jwtDecode} from 'jwt-decode';
import SessionExpired from '../Modals/SessionExpired';


const ChatBox = () => {
    const chatEndRef = useRef(null);
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');
    const navigate = useNavigate();
    const [loader,setLoader]=useState(false)

    const [expTime,setExpTime]=useState(0)
    

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [expiredModal, setExpiredModal] = useState(false);

    const [userId, setUserId] = useState(0);
    const [userData,setUserData]=useState({})
    const [chatHistory,setChatHistory]=useState([])

    

    const API_BASE_URL = "http://192.168.3.130:5000";

    useEffect(()=>{
        const token = getToken();
        if (token) {
            try {
                const decoded = jwtDecode(token); // Decode JWT token
                const expirationTime = decoded.exp * 1000; // Convert to milliseconds
                const currentTime = Date.now();
                const remainingTime = Math.max(0, expirationTime - currentTime);

                setExpTime(remainingTime);

                const interval = setInterval(() => {
                    setExpTime((prevTime) => {
                        if (prevTime <= 1000) {
                            clearInterval(interval);
                            setExpiredModal(true)
                            return 0;
                        }
                        return prevTime - 1000;
                    });
                }, 1000);

                return () => clearInterval(interval);
            } catch (error) {
                console.error("Invalid token:", error);
                setExpiredModal(true)
            }
        }


    },[])
    

    const formatTime = (milliseconds) => {
        const totalSeconds = Math.floor(milliseconds / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;
    
        return `${hours.toString().padStart(2, "0")}:` +
               `${minutes.toString().padStart(2, "0")}:` +
               `${seconds.toString().padStart(2, "0")}`;
    };
    

    // Toggle dropdown visibility
    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    // Toggle modal visibility
    const openModal = () => {
        setIsModalOpen(true);
        setIsDropdownOpen(false); // Close dropdown when modal is opened
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    const handleLogoutUser = async() => {
        try {
            const userlogout = await logoutUser();
           if(userlogout){
            navigate('/login');
           }
          
       } catch (error) {
           console.error('Error fetching data:', error);
       }
       
    };

     // Load user ID from localStorage on mount
    useEffect(() => {
        const userDetail = JSON.parse(localStorage.getItem('userData'));
        if (userDetail && userDetail.id) {
            setUserId(userDetail.id);
        }
    }, []);

    // Fetch data when userId is set
    useEffect(() => {
        if (!userId) return; // Prevent fetching if userId is 0
        const fetchData = async () => {
            try {
                 const userResponse = await getUserData(userId);
                // const userResponse = await axios.get(`http://localhost:5000/${userId}/data`);
                setUserData(userResponse);
               
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();

        const fetchChatHistory = async () => {
            try {
                const response = await axios.get(`${API_BASE_URL}/api/chat/${userId}/history`);
                setMessages(response.data);
            } catch (error) {
                console.error('Error fetching chat history:', error);
            }
        };

        fetchChatHistory();

        // Listen for real-time messages
        socket.on('message', (data) => {
            setMessages((prev) => [...prev, { sender: 'bot', message: data.aiMessage }]);
        });

        return () => {
            socket.off('message');
        };
    }, [userId]);

    // Log userData when it updates
    useEffect(() => {
        console.log("user_data",userData);
    }, [userData]);

   
    const sendMessage = async (e) => {
        e.preventDefault();
        if (!input.trim() || loader) return;
    
        setLoader(true); // Disable button
        try {
            const response = await axios.post(`${API_BASE_URL}/api/chat`, { userId, message: input });
    
            // Emit message event
            socket.emit('message', { userId, message: input, botReply: response.data.message });
    
            // Update local state with user and bot messages
            setMessages((prev) => [
                ...prev,
                { sender: 'user', message: input },
                { sender: 'bot', message: response.data.message }
            ]);
        } catch (error) {
            console.error('Error sending message:', error);
        } finally {
            setInput('');
            setTimeout(() => setLoader(false), 5000); // Enable button after 5 seconds
        }
    };

    const handleProfileUpdate = async (e) => {
            e.preventDefault();
            try {
                const data = await updateUserProfile(userId,userData.name,userData.email, userData.text_password);
                console.log("update_data",data)
                if(data){
                    setIsModalOpen(false);
                }
                
            } catch (error) {
                console.log("invalid user")
                // console.log("error",userId)
                navigate('/login');
            }
        };

  
    const [showPassword, setShowPassword] = useState(false);
    const handleShowPassword = () => {
        setShowPassword((prev) => !prev);
    };

    // const scrollToBottom = () => {
    //     chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    // };

    const scrollToBottom = () => {
        const chatContainer = chatEndRef.current?.parentNode;
        if (chatContainer) {
            const isNearBottom = chatContainer.scrollHeight - chatContainer.scrollTop <= chatContainer.clientHeight + 50;
            if (isNearBottom) {
                chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
            }
        }
    };

    useEffect(() => {
        scrollToBottom();
    }, [messages]);

    return (
        <>
            {expiredModal ? <SessionExpired setExpiredModal ={setExpiredModal} handleLogoutUser={handleLogoutUser}/> :"" }
            <div className="chat-page flex flex-col">
                <div className="nav flex justify-between p-4 px-10 bg-slate-300">
                    <div className="logo flex justify-center items-center gap-3 cursor-pointer">
                        <img src="/images/ai_chat_bot_icon.png" alt="icon" className="w-[30px] height-[30px]" />
                        <p className='text-[#d6358e] text-2xl font-bold '>Ai-ChatBot</p>
                      
                    </div>
                    <div className="profile">
                        <div className="cursor-pointer flex justify-center items-center gap-2" onClick={toggleDropdown}>
                            <i className="fa-solid fa-circle-user text-2xl "></i>
                            <span className='font-bold'>{userData ? userData.name : 'user'}</span>
                            <b className={`${expTime > 15000 ? 'text-green-600' : 'text-red-600'}`}>
                                {formatTime(expTime)}
                            </b>
                        </div>
                        {/* Dropdown */}
                        {isDropdownOpen && (
                            <div className="absolute right-0 mt-2 w-40 bg-white border  shadow-lg z-10">
                            <button
                                className="block w-full text-left bg-white px-4 py-2 text-gray-700 hover:text-white hover:bg-[#d6358e]"
                                onClick={openModal}
                            >
                                My Profile
                            </button>
                            <button
                                className="block w-full text-left px-4 py-2 bg-white text-gray-700 hover:text-white hover:bg-[#d6358e]"
                                onClick={handleLogoutUser}
                            >
                                Logout
                            </button>
                            </div>
                        )}

                        {/* Modal for My Profile */}
                            {isModalOpen && (
                                <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center z-20 ">
                                <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
                                    <h2 className="text-xl font-bold mb-4 text-center">My Profile</h2>
                                    <form onSubmit={handleProfileUpdate} autoComplete='off' className='mb-4 flex flex-col gap-3'>
                                    <div className='flex flex-col gap-2'>
                                        <div className="user-name">
                                            <label htmlFor="name">Name</label>
                                            <div>
                                                <input type="text" className='w-full' name="userName" id="userName" value={userData ? userData.name : ''} onChange={(e) => setUserData({ ...userData, name: e.target.value })}/>
                                            </div>
                                        </div>
                                        <div className="user-email">
                                            <label htmlFor="name">Email</label>
                                            <div className='w-full'>
                                            <input className='w-full' type="email" name="email" id="email" value={userData ? userData.email : ''} onChange={(e) => setUserData({ ...userData, email: e.target.value })}/>
                                            </div>
                                        </div>
                                        
                                       <div className="user-pass">
                                            <label htmlFor="userPassword">Password</label>
                                            <div className='w-full relative'>
                                                <input 
                                                className='w-full relative'
                                                    type={showPassword ? "text" : "password"} 
                                                    name="userPassword" 
                                                    id="userPassword" 
                                                    value={userData.text_password} 
                                                    onChange={(e) => setUserData({ ...userData, text_password: e.target.value })}
                                                />
                                                <span className='absolute right-1 top-1 bottom-1 cursor-pointer text-sm p-2 ms-2 bg-[#d6358ee5] hover:bg-[#d6358e] text-white rounded ' onClick={handleShowPassword}>
                                                    {showPassword ? "Hide" : "Show"}
                                                </span>
                                            </div>
                                        </div>

                                        <div className="update-btn">
                                            <button className='w-full'>Update</button>
                                        </div>
                                    </div>
                                    </form>
                                    <div className="mt-4 flex justify-end">
                                    <button
                                        className="px-4 py-2 text-xl font-semibold text-black bg-white absolute top-0 right-[2%]  rounded hover:text-black hover:bg-white"
                                        onClick={closeModal}
                                    >
                                        x
                                    </button>
                                   
                                    </div>
                                </div>
                                </div>
                            )}
                    </div>
                </div>
                <div className="chat-screen w-full h-full flex justify-center  items-end">
                    <div className="chat-container ">
                        <div className="messages flex flex-col gap-1">
                        <div className="message-chat mb-4 flex flex-col gap-1">
                        {messages.map((msg, index) => (
                                <div key={index} className={`message-bubble ${msg?.sender === 'user' ? 'user-msg' : 'bot-msg'}`}>
                                {(msg?.message ?? "").split("\n").map((line, i) => (
                                    <span key={i}>
                                        {line.split(/\*\*(.*?)\*\*/g).map((part, index) =>
                                            index % 2 === 1 ? <b key={index}>{part}</b> : part
                                        )}
                                        <br />
                                    </span>
                                ))}
                            </div>
                            ))}
                                {loader && <div className="bot-loader mt-2 bg-none ms-4"><Loader /></div>}
                                <div ref={chatEndRef} />
                            </div>
                            </div>
                            <form onSubmit={sendMessage} autoComplete='off' >

                            <div className="inputs w-full flex flex-col items-center">
                                <input
                                    type="text"
                                    value={input}
                                    onChange={(e) => setInput(e.target.value)}
                                    placeholder="Type a message..."
                                    className="min-w-[350px]"
                                    disabled={loader} // Disable input when sending
                                />
                                <button
                                    className="mt-2 min-w-[350px] bg-[#d6358ee5] text-white py-2 rounded-md hover:bg-[#d6358e] max-w-[450px]"
                                    disabled={loader} // Disable button when sending
                                >
                                    {loader ? 'Sending...' : 'Send'}
                                </button>
                        </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </>
        
    );
};

export default ChatBox;