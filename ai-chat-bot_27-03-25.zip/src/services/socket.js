// client/src/services/socket.js (WebSocket Service)
import { io } from 'socket.io-client';


const API_BASE_URL = "http://192.168.3.130:5000";
const SOCKET_URL = API_BASE_URL;

const socket = io(SOCKET_URL, { transports: ['websocket'] });

export default socket;