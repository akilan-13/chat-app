// client/src/pages/LoginPage.js (Login Page)
import React, { useState, useContext } from 'react';
import { loginUser } from '../services/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";
import PageLoader from '../components/PageLoader';


const LoginPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { setUser } = useContext(AuthContext);
    const navigate = useNavigate();
    const [error, setError] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [showLoading, setShowLoading] = useState(false);
    const handleShowPassword = () => {
        setShowPassword((prev) => !prev);
    };

    const handleLogin = async (e) => {
        setShowLoading(true)
        e.preventDefault();
        try {
            const data = await loginUser(email, password);
            localStorage.setItem('token', data.token);
            localStorage.setItem('userData', JSON.stringify(data));
            setUser(data);
            setShowLoading(false)
            navigate('/chat');
        } catch (error) {
            setShowLoading(false)
            setError("Invalid username or password. Please try again.");
        }
    };

   

    return (
       
 
        <div className="login-container w-100 h-screen flex justify-center items-center relative w-full h-screen primary_bg">
        {showLoading ? <PageLoader/> :''}
        <img
        src="/images/loginBackground.png"
        alt="background"
        className="absolute top-0 left-0 w-full h-full object-cover opacity-80"
    />
   
            <div className="register-card p-8 shadow-sm rounded-lg bg-white min-w-[350px] min-h-[350px] relative z-10 flex flex-col justify-center ">
            <h2 className='font-bold text-3xl  text-[#d6358e] text-center mb-4 '>Login</h2>
            <form onSubmit={handleLogin} autoComplete='off' className='mb-4 flex flex-col gap-3'>
                
                    <input type="text" className='outline-[#d6358e]' placeholder="Email or Username" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <div className="w-full relative">
                        <input 
                        type={showPassword ? "text" : "password"} 
                        placeholder="Password" className='w-full relative outline-[#d6358e]' 
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} required />
                        <span className='absolute right-1 top-1 bottom-1 cursor-pointer text-sm p-2 ms-2 bg-[#d6358ee5] hover:bg-[#d6358e] text-white rounded ' onClick={handleShowPassword}>
                            {showPassword ? "Hide" : "Show"}
                        </span>
                    </div>
                    <button type="submit">Login</button>
                
                
            </form>
           
            <p className="text-center mt-4">
                If You Dont't have an account?{" "}
                <span ><Link to="/" className="text-blue-500">Signup here</Link></span>
            </p>
            {error && <p className="text-xs font-semibold text-red-500 text-center mt-3">{error}</p>}
            </div>
        </div>
        
    );
};

export default LoginPage;