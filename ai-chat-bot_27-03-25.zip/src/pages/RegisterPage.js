// client/src/pages/RegisterPage.js (Register Page)
import React, { useState } from 'react';
import { registerUser } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";
import PageLoader from '../components/PageLoader';



const RegisterPage = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
      const [error, setError] = useState('');
      const [showPassword, setShowPassword] = useState(false);
      const [showLoading, setShowLoading] = useState(false);
        const handleShowPassword = () => {
            setShowPassword((prev) => !prev);
        };
    

    const handleRegister = async (e) => {
        setShowLoading(true)
        e.preventDefault();
        try {
            await registerUser(name, email, password);
            setShowLoading(false)
            navigate('/login');
        } catch (error) {
            setShowLoading(false)
            setError("Server Is Busy, Please try again.");
        }
    };

    return (
        <div className="register-container w-100 h-screen flex justify-center items-center primary_bg">
             {showLoading ? <PageLoader/> :''}
             <img
                    src="/images/loginBackground.png"
                    alt="background"
                    className="absolute top-0 left-0 w-full h-full object-cover opacity-80"
                />
            <div className="register-card p-8 rounded-lg bg-white min-w-[350px] min-h-[350px] relative z-10 flex flex-col justify-center">
                <h2 className='font-bold text-3xl  text-[#d6358e] text-center mb-4'>Signup</h2>
                <form onSubmit={handleRegister} className='mb-4 flex flex-col gap-3'>
                    <input type="text" className='outline-[#d6358e]' placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
                    <input type="email" className='outline-[#d6358e]' placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <div className="w-full relative">
                        <input 
                            type={showPassword ? "text" : "password"} 
                        className='w-full relative outline-[#d6358e]' 
                        placeholder="Password" 
                        value={password} 
                        onChange={(e) => setPassword(e.target.value)} required />
                        <span className='absolute right-1 top-1 bottom-1 cursor-pointer text-sm p-2 ms-2 bg-[#d6358ee5] hover:bg-[#d6358e] text-white rounded ' onClick={handleShowPassword}>
                            {showPassword ? "Hide" : "Show"}
                        </span>
                    </div>
                    <button type="submit">Signup</button>
                </form>
                <p className="text-center mt-4">
                    Already have an account?{" "}
                <span > <Link to="/login" className="text-blue-500" >Login here</Link></span>
                </p>
                {error && <p className="text-xs font-semibold text-red-500 text-center mt-3">{error}</p>}
            </div>
        </div>
    );
};

export default RegisterPage;