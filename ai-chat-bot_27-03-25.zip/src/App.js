import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ChatBox from './components/ChatBox';
import AuthProvider from './context/AuthContext';
import PrivateRoute from './components/PrivateRoute';

const App = () => {

    console.log("DB Name:", process.env.REACT_APP_DB_NAME);
    console.log("DB user:", process.env.REACT_APP_USER);

    return (
        <AuthProvider>
            <Router>
                <Routes>
                    <Route path="/" element={<RegisterPage />} />
                    <Route path="/login" element={<LoginPage />} />

                    {/* Protected route for /chat */}
                    <Route element={<PrivateRoute />}>
                        <Route path="/chat" element={<ChatBox />} />
                    </Route>
                </Routes>
            </Router>
        </AuthProvider>
    );
};

export default App;




// import Main from "./Component/Main";
// import Sidebar from "./Component/Sidebar";
// import { useState,useEffect } from "react";
// import{io} from 'socket.io-client'
// import Signup from "./Component/SignUp";
// import { useNavigate } from "react-router-dom";
// import {  Routes, Route } from "react-router-dom";
// import Login from "./Component/Login";



// const socket = io("http://localhost:6070");

// function App() {
//   const [chatMessage,setChatMessage]=useState("");
//   const [sidebar,setSidebar]=useState(false);
//   const [signPage,setSignPage]=useState(false);
//   const [loginPage,setLoginPage]=useState(false);
//   const [generalData,setGeneralData]=useState({});
//   const [username, setUsername] = useState("")
//   const [email, setEmail] = useState("");
//    const [password, setPassword] = useState("");
//    const navigate = useNavigate();
//   const [messages, setMessages] = useState([]); // State to store all chat messages

//   useEffect(() => {
//     // Load messages from WebSocket server
//     socket.on("message", (data) => {
//       setMessages((prevMessages) => [...prevMessages, data]);
//     });

//     // Load previous messages on first render
//     socket.on("loadMessages", (history) => {
//       setMessages(history);
//     });

//     fetch("http://localhost:6070/api/auth/generalData") 
//     .then((response) => response.json())
//     .then((data) => {setGeneralData(data.data); console.log(data.data)}) 
//     .catch((error) => console.error("Error fetching icon:", error));

//     return () => {
//       socket.disconnect();
//     };
//   }, []);

//   // Send a message
//   const sendMessage = () => {
    
//     if (chatMessage.trim() !== "" && username.trim() !== "") {
//       socket.emit("message", { username, message: chatMessage });
//       setChatMessage(""); // Clear input field
//     }
//   };


//   const handleSignup = async (e) => {

//     e.preventDefault();
    

//     const response = await fetch("http://localhost:6070/api/auth/signup", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ username, email, password }),
//     });

//     const data = await response.json();
//     if (data.success) {
//       alert("Signup successful! You can now login.");
//       setPassword("")
//       setEmail("")
//       setUsername("")
//       setSignPage(true)
//       navigate("/");
//     } else {
//       alert("Signup failed: " + data.error);
//     }
//   };

//   const handleLogin = async (e) => {
//     e.preventDefault();
    

//     const response = await fetch("http://localhost:6070/api/auth/login", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ username, password }),
//     });

//     const data = await response.json();
//     if (data.success) {
//       alert("Login successfully");
//       setPassword("")
//       setEmail("")
//       setUsername("")
//       setLoginPage(false)
//       setSignPage(false)
//       navigate("/");
//     } else {
//       console.log(data)
//       alert("Login failed: " + data.error);
//     }
//   };

//   const handleLoginPage=()=>{
//       setPassword("")
//       setSidebar(false)
//       setEmail("")
//       setUsername("")
//       setLoginPage(true);
//       setSignPage(false);    
//   }
//   const handleSignupPage=()=>{
//     setPassword("")
//     setEmail("")
//     setSidebar(false)
//     setUsername("")
//     setSignPage(true);
//     setLoginPage(false);
  
// }

//   return (<>
  
//     <div className="App flex h-screen w-full">
//             <Routes>
//               <Route path="/login" element={<h1><Login
//                 handleLogin={handleLogin}
//                 setPassword={setPassword}
//                 setUsername={setUsername}
//                 handleLoginPage={handleLoginPage}
//                 username={username}
//                 password={password}
//                 loginPage={loginPage}
//                 signPage={signPage}
//               /></h1>} />
          
//                 <Route path="/signup" element={<Signup
//                 handleSignup={handleSignup}
//                 setPassword={setPassword}
//                 setUsername={setUsername}
//                 handleSignupPage={handleSignupPage}
//                 setEmail={setEmail}
//                 username={username}
//                 email={email}
//                 signPage={signPage}
//                 loginPage={loginPage}
//                 password={password}
//                 />} />
//           </Routes>
     
//           { sidebar ?
//           <Sidebar
//            sidebar={sidebar}
//            setSidebar={setSidebar}
//            signPage={signPage}
//            loginPage={loginPage}
//            />
//            :<></>
//           }
 
//           <Main 
//           sendMessage={sendMessage} 
//           chatMessage={chatMessage} 
//           setChatMessage={setChatMessage}
//           sidebar={sidebar}
//           setSidebar={setSidebar}
//           messages={messages}
//           setUsername={setUsername}
//           handleSignupPage={handleSignupPage}
//           handleLoginPage={handleLoginPage}
//           username={username}
//           signPage={signPage}
//           loginPage={loginPage}
//           generalData={generalData}
//           />
      
//     </div>
    
       
//     </>
//   );
// }

// export default App;
