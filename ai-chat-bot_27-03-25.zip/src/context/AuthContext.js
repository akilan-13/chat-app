import React, { createContext, useState, useEffect } from 'react';
import { getToken, logoutUser } from '../services/api';
import {jwtDecode} from 'jwt-decode';

export const AuthContext = createContext();

const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        const token = getToken();
        if (token) {
            const decodedToken = jwtDecode(token);
            const currentTime = Date.now() / 1000; // Convert to seconds
            
            if (decodedToken.exp < currentTime) {
                alert("Session expired! Please log in again.");
                handleLogout();
            } else {
                setUser({ token });

                // Calculate time remaining before expiration
                const expiresIn = (decodedToken.exp - currentTime) * 1000; // Convert to milliseconds
                
                // Set a timeout to automatically log the user out when token expires
                setTimeout(() => {
                    alert("Session expired! Please log in again.");
                    handleLogout();
                }, expiresIn);
            }
        }
    }, []);

    const handleLogout = () => {
        logoutUser();
        setUser(null);
    };

    return (
        <AuthContext.Provider value={{ user, setUser, logout: handleLogout }}>
            {children}
        </AuthContext.Provider>
    );
};

export default AuthProvider;
