// server/websocket.js (WebSocket Setup)
import { Server } from 'socket.io';

const setupWebSocket = (server) => {
    const io = new Server(server, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
        },
    });

    io.on('connection', (socket) => {
        console.log('New WebSocket connection:', socket.id);
        
        socket.on('message', (data) => {
            io.emit('message', data);
        });
    });

    return io;
};

export default setupWebSocket;