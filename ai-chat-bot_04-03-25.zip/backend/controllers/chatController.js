// server/controllers/chatController.js (Chatbot Logic with AI Fallback - MySQL)
import asyncHandler from 'express-async-handler';
import { saveChatMessage, getChatHistory } from '../models/ChatModel.js';
import axios from 'axios';

const openAiFreeTrialKey = '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';
const togetherApi = '616a73d21c4d1749a3671db5c9c42668afc783ccc76d7d5eb51f7defa03010b3';

// deepseek
const deepseekApiKey = "sk-a79b33c3affa4a00af01b7ee24b5d9ae";
const deepsekEndpoint = "https://api.deepseek.com/v1"; // Endpoint for DeepSeek API
const deepseekModelName = "deepseek-chat";

const deepseek_Api_Key="sk-a79b33c3affa4a00af01b7ee24b5d9ae";
// deepseek
const getDeepSeekResponse = async (message) => {
    try {
        const response = await axios.post(
            `${deepsekEndpoint}/chat/completions`,
            {
                model: deepseekModelName,
                messages: [{ role: "user", content: message }],
                max_tokens: 200,
            },
            {
                headers: {
                    Authorization: `Bearer ${deepseekApiKey}`,
                    'Content-Type': 'application/json',
                }
            }
        );

        // Handle the response
        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return response.data.choices[0].message.content.trim();
        } else {
            console.error("DeepSeek API returned unexpected response:", response.data);
            return { message: "DeepSeek API returned an unexpected response.", success: false };
        }
    } catch (error) {
        if (error.response && error.response.data) {
            console.error('DeepSeek API failed:', error.response.data);
            // Check for bad credentials or authorization errors
            if (error.response.data.error && error.response.data.error.code === 'unauthorized') {
                return { message: "DeepSeek API failed due to bad credentials. Please check your API key.", success: false };
            }
        }
        console.error('DeepSeek API failed:', error.message);
        return { message: "Service is currently unavailable or an error occurred with DeepSeek.", success: false };
    }
};

// OpenAI API Call
const getOpenAIResponse = async (message) => {
    try {
        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: 'gpt-4',
                messages: [{ role: 'user', content: message }],
                max_tokens: 200,
            },
            {
                headers: {
                    Authorization: `Bearer ${openAiFreeTrialKey}`,
                    'Content-Type': 'application/json',
                },
            }
        );
        return { message: response.data.choices[0].message.content.trim(), success: true };
    } catch (error) {
        console.error('OpenAI API failed:', error.message);
        return { message: "OpenAI API failed. Please try again later.", success: false };
    }
};

// Llama API Call
const getLlamaResponse = async (message) => {
    try {
        const response = await axios.post(
            'https://api.together.xyz/v1/chat/completions',
            {
                model: "meta-llama/Llama-2-7b-chat-hf",
                messages: [{ role: "user", content: message }],
                max_tokens: 200
            },
            {
                headers: {
                    Authorization: `Bearer ${togetherApi}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return { message: response.data.choices[0].message.content.trim(), success: true };
        } else {
            console.error("LLaMA 2 API returned unexpected response:", response.data);
            return { message: "LLaMA 2 API returned an unexpected response.", success: false };
        }
    } catch (error) {
        console.error('LLaMA 2 API failed:', error.response?.data || error.message);
        return { message: "LLaMA 2 API failed. Please try again later.", success: false };
    }
};

// GPT4All API Call
const getGPT4AllResponse = async (message) => {
    try {
        const response = await axios.post(
            'https://api.together.xyz/v1/completions',
            {
                model: 'togethercomputer/llama-2-7b-chat',
                prompt: message,
                max_tokens: 200,
            },
            {
                headers: {
                    Authorization: `Bearer your_together_ai_api_key`,
                    'Content-Type': 'application/json',
                },
            }
        );
        return { message: response.data.choices[0].text.trim(), success: true };
    } catch (error) {
        console.error('GPT4All API failed:', error.message);
        return { message: "GPT4All API failed. Please try again later.", success: false };
    }
};

// Vicuna API Call
const getVicunaResponse = async (message) => {
    try {
        const response = await axios.post(
            'http://localhost:5001/generate',
            { prompt: message },
            { headers: { 'Content-Type': 'application/json' } }
        );
        return { message: response.data.response.trim(), success: true };
    } catch (error) {
        console.error('Vicuna API failed:', error.message);
        return { message: 'Vicuna API failed. Please try again later.', success: false };
    }
};

// Main Chat Controller with AI Fallback
export const chatWithAI = asyncHandler(async (req, res) => {
    const { userId, message } = req.body;

    await saveChatMessage(userId, message, 'user');

    let aiMessage = await getDeepSeekResponse(message);
    if (!aiMessage.success) {
        aiMessage = await getOpenAIResponse(message);
    }
    if (!aiMessage.success) {
        aiMessage = await getLlamaResponse(message);
    }
    if (!aiMessage.success) {
        aiMessage = await getGPT4AllResponse(message);
    }
    await saveChatMessage(userId, aiMessage.message, 'bot');
    res.json({ message: aiMessage.message });
});
// Chat History Controller
export const getChatHistoryController = asyncHandler(async (req, res) => {
    const { userId } = req.params;
    const chatHistory = await getChatHistory(userId);
    res.json(chatHistory);
});
