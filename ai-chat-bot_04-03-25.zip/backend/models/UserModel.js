// server/models/UserModel.js (User Model - MySQL)
import connectDB from '../config/db.js';

export const createUser = async (name, email, password) => {
    const connection = await connectDB();
    const [result] = await connection.execute(
        'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
        [name, email, password]
    );
    return result;
};

export const findUserByEmail = async (email) => {
    const connection = await connectDB();
    const [rows] = await connection.execute('SELECT * FROM users WHERE email = ? OR name = ?', [email, email]);
    return rows[0];
};
