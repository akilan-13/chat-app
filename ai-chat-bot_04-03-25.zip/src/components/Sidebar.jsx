
const Sidebar=({sidebar,setSidebar ,loginPage,signPage})=>{

    return(<>
    { (!loginPage && !signPage) ?
        <div className="w-auto primary_bg">
            <div className="flex text-white justify-between flex ">
                <span className="flex justify-between p-3 shadow-md" data-state="closed">
                    <button aria-label="Close sidebar" onClick={()=>setSidebar(false)} data-testid="close-sidebar-button" className="h-10 grow-0 rounded-lg px-2 text-token-text-secondary focus-visible:bg-token-surface-hover focus-visible:outline-0 enabled:hover:bg-token-surface-hover disabled:text-token-text-quaternary no-draggable">
                        <i className="fa-solid fa-bars"></i>
                    </button>
                    <button aria-label="Ctrl K" className="h-10  rounded-lg px-2 text-token-text-secondary focus-visible:bg-token-surface-hover focus-visible:outline-0 enabled:hover:bg-token-surface-hover disabled:text-token-text-quaternary">
                    <i className="fa-solid fa-magnifying-glass"></i>
                    </button>
                    <button aria-label="New chat" data-testid="create-new-chat-button" className="h-10 rounded-lg px-2 text-token-text-secondary focus-visible:bg-token-surface-hover focus-visible:outline-0 enabled:hover:bg-token-surface-hover disabled:text-token-text-quaternary">
                    <i className="fa-solid fa-up-right-from-square"></i>
                    </button>
                </span>
            </div>

        </div>
        :<></>
    }
    </>);

}

export default Sidebar;