// client/src/pages/LoginPage.js (Login Page)
import React, { useState, useContext } from 'react';
import { loginUser } from '../services/api';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";


const LoginPage = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const { setUser } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        try {
            const data = await loginUser(email, password);
            localStorage.setItem('token', data.token);
            setUser(data);
            navigate('/chat');
        } catch (error) {
            console.error('Login failed', error);
        }
    };

    return (
    
 
        <div className="login-container w-100 h-screen flex justify-center items-center relative w-full h-screen primary_bg">
        <img
        src="/images/loginBackground.png"
        alt="background"
        className="absolute top-0 left-0 w-full h-full object-cover opacity-80"
    />
   
            <div className="register-card p-8 shadow-sm rounded-lg bg-white min-w-[350px] min-h-[350px] relative z-10 flex flex-col justify-center ">
            <h2 className='font-bold text-3xl  text-[#d6358e] text-center mb-4 '>Login</h2>
            <form onSubmit={handleLogin} autoComplete='off' >
                <div className=' flex flex-col justify-center items-center gap-3 '>
                    <input type="text" className='outline-[#d6358e]' placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <input type="password" placeholder="Password" className='outline-[#d6358e]' value={password} onChange={(e) => setPassword(e.target.value)} required />
                    <button className='bg-[#d6358ee5] text-white py-2 rounded-md hover:bg-[#d6358e]' type="submit">Login</button>
                </div>
                
            </form>
            <p className="text-center mt-4">
                If You Dont't have an account?{" "}
                <span ><Link to="/" className="text-blue-500">Signup here</Link></span>
            </p>
            </div>
        </div>
        
    );
};

export default LoginPage;