// client/src/components/ChatBox.js (Chat UI Component)
import React, { useState, useEffect } from 'react';
import socket from '../services/socket';
import axios from 'axios';
import './ChatBox.css';

const ChatBox = ({ userId }) => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState('');

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Toggle dropdown visibility
    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    // Toggle modal visibility
    const openModal = () => {
        setIsModalOpen(true);
        setIsDropdownOpen(false); // Close dropdown when modal is opened
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };

    useEffect(() => {
        socket.on('message', (message) => {
            setMessages((prevMessages) => [...prevMessages, message]);
        });
    }, []);

    const sendMessage = async () => {
        if (input.trim()) {
            const response = await axios.post('http://localhost:5000/api/chat', { userId, message: input });
            socket.emit('message', { userId, message: input, botReply: response.data.message });
            setMessages((prev) => [...prev, { sender: 'user', message: input }, { sender: 'bot', message: response.data.message }]);
            setInput('');
        }
    };

    return (
        <>
            <div className="chat-page flex flex-col">
                <div className="nav flex justify-between p-4 px-10 bg-slate-300">
                    <div className="logo flex justify-center items-center gap-3 cursor-pointer">
                        <img src="/images/ai_chat_bot_icon.png" alt="icon" className="w-[30px] height-[30px]" />
                        <p className='text-[#d6358e] text-2xl font-bold '>Ai-ChatBot</p>
                    </div>
                    <div className="profile">
                        <div className="cursor-pointer flex justify-center items-center gap-2" onClick={toggleDropdown}>
                            <i className="fa-solid fa-circle-user text-2xl "></i>
                            <span className='font-bold'>User</span>
                        </div>
                        {/* Dropdown */}
                        {isDropdownOpen && (
                            <div className="absolute right-0 mt-2 w-40 bg-white border  shadow-lg z-10">
                            <button
                                className="block w-full text-left bg-white px-4 py-2 text-gray-700 hover:text-white hover:bg-[#d6358e]"
                                onClick={openModal}
                            >
                                My Profile
                            </button>
                            <button
                                className="block w-full text-left px-4 py-2 bg-white text-gray-700 hover:text-white hover:bg-[#d6358e]"
                                onClick={() => alert('Logging out...')}
                            >
                                Logout
                            </button>
                            </div>
                        )}

                        {/* Modal for My Profile */}
                            {isModalOpen && (
                                <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center z-20">
                                <div className="bg-white p-6 rounded-lg shadow-lg w-96">
                                    <h2 className="text-xl font-bold mb-4">My Profile</h2>
                                    <p>This is your profile modal content.</p>
                                    <div className="mt-4 flex justify-end">
                                    <button
                                        className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-700"
                                        onClick={closeModal}
                                    >
                                        Close
                                    </button>
                                    </div>
                                </div>
                                </div>
                            )}
                    </div>
                </div>
                <div className="chat-screen w-full h-full flex justify-center  items-end">
                    <div className="chat-container ">
                        <div className="messages flex flex-col gap-1">
                            <div  className='message-chat mb-4 flex flex-col gap-1'> 
                                    {messages.map((msg, index) => (
                                        <div key={index} className={msg.sender === 'user' ? 'user-msg' : 'bot-msg'}>
                                            {msg.message}
                                        </div>
                                    ))}
                                </div>
                            </div>

                        <div className="inputs w-full flex flex-col items-center">
                            <input 
                                type="text" 
                                value={input} 
                                onChange={(e) => setInput(e.target.value)}
                                placeholder="Type a message..."
                                className='min-w-[350px]'
                            />
                            <button className='mt-2 min-w-[350px] bg-[#d6358ee5] text-white py-2 rounded-md hover:bg-[#d6358e] max-w-[450px]' onClick={sendMessage}>Send</button>

                        </div>
                        
                    </div>
                </div>
            </div>
        </>
        
    );
};

export default ChatBox;