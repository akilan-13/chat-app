import { Link } from "react-router-dom";
import {icon} from "../"
const Main=({sendMessage,chatMessage,setChatMessage,generalData,setSidebar,sidebar,messages,handleSignupPage,handleLoginPage,loginPage,signPage})=>{
   
    return(<>
    { (!loginPage && !signPage) ?
       <div className="w-full bg-white flex flex-col h-screen chat-page">
        {/* Header */}
        <div className="flex justify-between p-4 border-b shadow-md">
          {sidebar ? (
            <h4 className="ml-2 text-lg flex gap-2 text-[#d6358e]"> 
                
            {generalData.fav_icon ? (
      <img src={`/images/${generalData.fav_icon}`} alt="Icon" width={30} height={10} />
    ) : (
      <p></p>
    )}
           <span> Ai-ChatBot</span></h4>
          ) : (
            <div className="flex items-center">
              <button
                aria-label="Toggle Sidebar"
                onClick={() => setSidebar(!sidebar)}
                className="text-[#d6358e] h-10 px-2 rounded-lg focus:outline-none"
              >
               <i className="fa-solid fa-bars"></i>
              </button>
              <h4 className="ml-2 text-lg flex gap-2 text-[#d6358e]"> 
                
              {generalData.fav_icon ? (
        <img src={`/images/${generalData.fav_icon}`} alt="Icon" width={30} height={10} />
      ) : (
        <p></p>
      )}
             <span> Ai-ChatBot</span></h4>
            </div>
          )}
          <div className="btn flex gap-2">
            <button className="px-3 py-1 text-white bg-[#d6358e] rounded-lg" onClick={handleLoginPage}><Link to="/login" > Login </Link></button>
            <button className="px-3 py-1 border rounded-lg" onClick={handleSignupPage}><Link to="/signup" > Signup </Link></button>
          </div> 
        </div>

        {/* Chat Messages */}
        <div className="flex flex-col items-center justify-center message px-0 py-4 w-full">
          <h2 className="py-2 mb-2 text-center">What can I help with?</h2>
          <div className="h-full overflow-y-auto p-2 mb-2 w-full">
              {messages.map((msg, index) => (
                <p key={index} className="p-1 border-b">
                  <strong>{msg.username}:</strong> {msg.message} 
                  <span className="text-gray-400 text-xs ml-2">{new Date(msg.timestamp).toLocaleTimeString()}</span>
                </p>
              ))}
            </div>
           {/* Message Input */}
           <div className="flex border rounded px-2 py-1">
              <input
                type="text"
                className="flex-1 px-2 py-2 outline-none"
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                placeholder="Type a message..."
              />
              <button
                className="bg-[#d6358e] text-white px-4 py-1 rounded"
                onClick={sendMessage}
              >
                Send
              </button>
            </div>
        </div>
      </div>
       :<></>
      }
    </>);

}

export default Main;