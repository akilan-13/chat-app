// client/src/pages/RegisterPage.js (Register Page)
import React, { useState } from 'react';
import { registerUser } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { Link } from "react-router-dom";


const RegisterPage = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleRegister = async (e) => {
        e.preventDefault();
        try {
            await registerUser(name, email, password);
            navigate('/login');
        } catch (error) {
            console.error('Registration failed', error);
        }
    };

    return (
        <div className="register-container w-100 h-screen flex justify-center items-center primary_bg">
             <img
        src="/images/loginBackground.png"
        alt="background"
        className="absolute top-0 left-0 w-full h-full object-cover opacity-80"
    />
            <div className="register-card p-8 rounded-lg bg-white min-w-[350px] min-h-[350px] relative z-10 flex flex-col justify-center">
                <h2 className='font-bold text-3xl  text-[#d6358e] text-center mb-4'>Signup</h2>
                <form onSubmit={handleRegister} className='mb-4 flex flex-col gap-3'>
                    <input type="text" className='outline-[#d6358e]' placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
                    <input type="email" className='outline-[#d6358e]' placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                    <input type="password" className='outline-[#d6358e]' placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                    <button type="submit">Signup</button>
                </form>
                <p className="text-center mt-4">
                    Already have an account?{" "}
                <span > <Link to="/login" className="text-blue-500" >Login here</Link></span>
                </p>
            </div>
        </div>

    );
};

export default RegisterPage;