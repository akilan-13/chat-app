// server/controllers/chatController.js (Chatbot Logic with AI Fallback - MySQL)
import asyncHandler from 'express-async-handler';
import { saveChatMessage, getChatHistory } from '../models/ChatModel.js';
import axios from 'axios';

const openAiFreeTrialKey = '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';
const togetherApi = '616a73d21c4d1749a3671db5c9c42668afc783ccc76d7d5eb51f7defa03010b3';


// deepseek
const deepseekApiKey = "sk-a79b33c3affa4a00af01b7ee24b5d9ae";
const deepsekEndpoint = "https://api.deepseek.com/v1"; // Endpoint for DeepSeek API
const deepseekModelName = "deepseek-chat";

const huggingFaceApiKey = "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";

const llamaApi = "https://api-inference.huggingface.co/models/meta-llama/Llama-2-7b-chat-hf";
const mistralApi = "https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct";
const falconApi = "https://api-inference.huggingface.co/models/tiiuae/falcon-7b-instruct";
const gptJApi = "https://api-inference.huggingface.co/models/EleutherAI/gpt-j-6B";

const deepseek_Api_Key="sk-a79b33c3affa4a00af01b7ee24b5d9ae";
// deepseek
const getDeepSeekResponse = async (message) => {
    try {
        const response = await axios.post(
            `https://api.together.xyz/v1/chat/completions`,
            {
                model: 'deepseek-ai/DeepSeek-R1',
                messages: [{ role: "user", content: message }],
                max_tokens: 200,
            },
            {
                headers: {
                    Authorization: `Bearer ${deepseekApiKey}`,
                    'Content-Type': 'application/json',
                }
            }
        );

        // Handle the response
        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return response.data.choices[0].message.content.trim();
        } else {
            console.error("DeepSeek API returned unexpected response:", response.data);
            return { message: "DeepSeek API returned an unexpected response.", success: false };
        }
    } catch (error) {
        if (error.response && error.response.data) {
            console.error('DeepSeek API failed:', error.response.data);
            // Check for bad credentials or authorization errors
            if (error.response.data.error && error.response.data.error.code === 'unauthorized') {
                return { message: "DeepSeek API failed due to bad credentials. Please check your API key.", success: false };
            }
        }
        console.error('DeepSeek API failed:', error.message);
        return { message: "Service is currently unavailable or an error occurred with DeepSeek.", success: false };
    }
};

const getGoogleGemmaResponse = async (message) => {
    try {
        const response = await axios.post(
            `https://api.together.xyz/v1/chat/completions`,
            {
                model: 'google/gemma-2-9b-it',
                messages: [{ role: "user", content: message }],
                max_tokens: 200,
            },
            {
                headers: {
                    Authorization: `Bearer ${deepseekApiKey}`,
                    'Content-Type': 'application/json',
                }
            }
        );

        // Handle the response
        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return response.data.choices[0].message.content.trim();
        } else {
            console.error("DeepSeek API returned unexpected response:", response.data);
            return { message: "DeepSeek API returned an unexpected response.", success: false };
        }
    } catch (error) {
        if (error.response && error.response.data) {
            console.error('DeepSeek API failed:', error.response.data);
            // Check for bad credentials or authorization errors
            if (error.response.data.error && error.response.data.error.code === 'unauthorized') {
                return { message: "DeepSeek API failed due to bad credentials. Please check your API key.", success: false };
            }
        }
        console.error('DeepSeek API failed:', error.message);
        return { message: "Service is currently unavailable or an error occurred with DeepSeek.", success: false };
    }
};


// free api
const getLlamaResponse_3 = async (message) => {
    try {
        const response = await axios.post(
            'https://api.together.xyz/v1/chat/completions',
            {
                model: "meta-llama/Llama-Vision-Free",
                messages: [{ role: "user", content: message }],
                max_tokens: 200
            },
            {
                headers: {
                    Authorization: `Bearer ${togetherApi}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return { message: response.data.choices[0].message.content.trim(), success: true };
        } else {
            console.error("LLaMA 2 API returned unexpected response:", response.data);
            return { message: "LLaMA 2 API returned an unexpected response.", success: false };
        }
    } catch (error) {
        console.error('LLaMA 2 API failed:', error.response?.data || error.message);
        return { message: "LLaMA 2 API failed. Please try again later.", success: false };
    }
};
// Llama API Call
const getLlamaResponse = async (message) => {
    try {
        const response = await axios.post(
            'https://api.together.xyz/v1/chat/completions',
            {
                model: "meta-llama/Llama-2-7b-chat-hf",
                messages: [{ role: "user", content: message }],
                max_tokens: 200
            },
            {
                headers: {
                    Authorization: `Bearer ${togetherApi}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        if (response.data && response.data.choices && response.data.choices.length > 0) {
            return { message: response.data.choices[0].message.content.trim(), success: true };
        } else {
            console.error("LLaMA 2 API returned unexpected response:", response.data);
            return { message: "LLaMA 2 API returned an unexpected response.", success: false };
        }
    } catch (error) {
        console.error('LLaMA 2 API failed:', error.response?.data || error.message);
        return { message: "LLaMA 2 API failed. Please try again later.", success: false };
    }
};


// common ai integratiob=n function
const getChatResponse = async (apiUrl, message) => {
    try {
        const response = await axios.post(
            apiUrl,
            { inputs: message },
            {
                headers: {
                    Authorization: `Bearer ${huggingFaceApiKey}`,
                    'Content-Type': 'application/json',
                },
            }
        );

        if (response.data && response.data.length > 0) {
            return { message: response.data[0].generated_text.trim(), success: true };
        } else {
            console.error("Unexpected API response:", response.data);
            return { message: "Unexpected response from API.", success: false };
        }
    } catch (error) {
        console.error('API Error:', error.response?.data || error.message);
        return { message: "API request failed. Please try again later.", success: false };
    }
};
// Individual model functions
const getLlamaResponse3 = async (message) => getChatResponse(llamaApi, message);
const getMistralResponse = async (message) => getChatResponse(mistralApi, message);
const getFalconResponse = async (message) => getChatResponse(falconApi, message);
const getGptJResponseold = async (message) => getChatResponse(gptJApi, message);


// Main Chat Controller with AI Fallback
export const chatWithAI = asyncHandler(async (req, res) => {
    const { userId, message } = req.body;

    await saveChatMessage(userId, message, 'user');

    // let aiMessage = await getDeepSeekResponse(message);
    let aiMessage = await getLlamaResponse_3(message);
    if (!aiMessage.success) {
        aiMessage = await getLlamaResponse(message);
    }
    if (!aiMessage.success) {
        aiMessage = await getGPT4AllResponse(message);
    }
    if (!aiMessage.success) {
        aiMessage = await getFalconResponse(message);
    }
    if (!aiMessage.success) {
        aiMessage = await getGptJResponse(message);
    }
    await saveChatMessage(userId, aiMessage.message, 'bot');
    res.json({ message: aiMessage.message });
});
// Chat History Controller
export const getChatHistoryController = asyncHandler(async (req, res) => {
    const { userId } = req.params;
    const chatHistory = await getChatHistory(userId);
    res.json(chatHistory);
});
