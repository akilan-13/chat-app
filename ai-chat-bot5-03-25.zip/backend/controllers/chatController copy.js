
// server/controllers/chatController.js (Chatbot Logic with AI Fallback - MySQL)
import asyncHandler from 'express-async-handler';
import { saveChatMessage, getChatHistory } from '../models/ChatModel.js';
import axios from 'axios';
import { execSync } from 'child_process';

const openAiFreeTrialKey='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';

const getLlamaResponse = (message) => {
    try {
        const response = execSync(`ollama run llama2 "${message}"`, { encoding: 'utf-8' });
        return response.trim();
    } catch (error) {
        console.error('LLaMA 2 failed:', error.message);
        return null;
    }
};

const getGPT4AllResponse = (message) => {
    try {
        const response = execSync(`gpt4all --prompt "${message}"`, { encoding: 'utf-8' });
        return response.trim();
    } catch (error) {
        console.error('GPT4All failed:', error.message);
        return null;
    }
};

const getVicunaResponse = async (message) => {
    try {
        const response = await axios.post(
            'http://localhost:5001/generate',
            { prompt: message },
            { headers: { 'Content-Type': 'application/json' } }
        );
        return response.data.response;
    } catch (error) {
        console.error('Vicuna failed:', error.message);
        return 'I am currently experiencing issues. Please try again later.';
    }
};

export const chatWithAI = asyncHandler(async (req, res) => {
    const { userId, message } = req.body;

    await saveChatMessage(userId, message, 'user');

    let aiMessage = getOpenAIResponse(message) || getLlamaResponse(message) || getGPT4AllResponse(message) || await getVicunaResponse(message);

    await saveChatMessage(userId, aiMessage, 'bot');

    res.json({ message: aiMessage });
});

export const getChatHistoryController = asyncHandler(async (req, res) => {
    const { userId } = req.params;
    const chatHistory = await getChatHistory(userId);
    res.json(chatHistory);
});