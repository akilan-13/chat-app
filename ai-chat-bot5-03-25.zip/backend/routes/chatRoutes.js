// server/routes/chatRoutes.js (Chat Routes - MySQL with WebSocket Support)
import express from 'express';
import { chatWithAI, getChatHistoryController } from '../controllers/chatController.js';
import { saveChatMessage } from '../models/ChatModel.js';

const router = express.Router();

router.post('/', async (req, res) => {
    const { userId, message, socketId } = req.body;
    const aiMessage = await chatWithAI(req, res);
    req.app.get('io').emit('message', { userId, message, aiMessage, socketId });
    // await saveChatMessage(userId, aiMessage, 'bot');
});

router.get('/:userId/history', getChatHistoryController);

export default router;