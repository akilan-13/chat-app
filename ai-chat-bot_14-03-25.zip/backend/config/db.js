// server/config/db.js (Database Connection - MySQL)
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

// const db= mySql.createConnection({
//     host:"localhost",
//     user:"root",
//     password:"",
//     database:"ai_chatbot",
// })

const connectDB = async () => {
    try {
        const connection = await mysql.createConnection({
            host:"localhost",
            user:"root",
            password:"",
            database:"ai_chatbot",
        });
        console.log('MySQL Connected');
        return connection;
    } catch (error) {
        console.error(`Error: ${error.message}`);
        process.exit(1);
    }
};

export default connectDB;