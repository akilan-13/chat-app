// server/models/ChatModel.js (Chat Model - MySQL)
import connectDB from '../config/db.js';

export const saveChatMessage = async (userId, message, sender) => {
    userId = userId || "-";
    message = message || "-";
    sender = sender || "0";

    const connection = await connectDB();
    const [result] = await connection.execute(
        'INSERT INTO chat_messages (user_id, message, sender) VALUES (?, ?, ?)',
        [userId, message, sender]
    );
    return result;
};

export const getChatHistory = async (userId) => {
    const connection = await connectDB();
    const [rows] = await connection.execute(
        'SELECT * FROM chat_messages WHERE user_id = ? ORDER BY created_at ASC',
        [userId]
    );
    return rows;
};


export const getUserData = async (userId) => {
    const connection = await connectDB();
    const [rows] = await connection.execute(
        'SELECT * FROM users WHERE id = ? ORDER BY created_at ASC LIMIT 1',
        [userId]
    );
    await connection.end(); // Close the connection
    return rows.length ? rows[0] : null; // Return first row or null if not found
};