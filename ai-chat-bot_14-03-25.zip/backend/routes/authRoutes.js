// server/routes/authRoutes.js (Authentication Routes - MySQL)
import express from 'express';
import { registerUser, loginUser ,updateUserProfile } from '../controllers/authController.js';

const router = express.Router();

router.post('/register', registerUser);
router.post('/login', loginUser);
router.post('/updateUserProfile', updateUserProfile);

export default router;