// server/routes/chatRoutes.js (Chat Routes - MySQL with WebSocket Support)
import express from 'express';
import { chatWithAI, getChatHistoryController,getUserDataController } from '../controllers/chatController.js';
import { saveChatMessage } from '../models/ChatModel.js';

const router = express.Router();

router.post('/', async (req, res) => {
    try {
        const { userId, message, socketId } = req.body;
        
        if (!message) {
            return res.status(400).json({ error: "Message cannot be empty" });
        }

        const aiMessage = await chatWithAI(req, res);

        if (!aiMessage || !aiMessage.message) {
            return res.status(500).json({ error: "Failed to generate AI response" });
        }

        req.app.get('io').emit('message', { userId, message, aiMessage: aiMessage.message, socketId });

        res.json({ message: aiMessage.message });

    } catch (error) {
        console.error('Error processing message:', error);
        if (!res.headersSent) {
            res.status(500).json({ error: 'Internal server error' });
        }
    }
});



router.get('/:userId/history', getChatHistoryController);
router.get('/:userId/data', getUserDataController);

export default router;