// client/src/services/api.js (API Service for Authentication)
import axios from 'axios';

const API_URL = 'http://localhost:5000/api/auth';
const API_URL_chat = 'http://localhost:5000/api/chat';

export const registerUser = async (name, email, password) => {
    const response = await axios.post(`${API_URL}/register`, { name, email, password });
    return response.data;
};

export const loginUser = async (email, password) => {
    const response = await axios.post(`${API_URL}/login`, { email, password });
    return response.data;
};

export const updateUserProfile = async (id,name,email, password) => {
    const response = await axios.post(`${API_URL}/updateUserProfile`, {id,name, email, password });
    return response.data;
};

export const logoutUser = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userData');
    return "logout";
};

export const getToken = () => {
    return localStorage.getItem('token');
};

export const getUserData = async (userId) => {
    const response = await axios.get(`${API_URL_chat}/${userId}/data`);
    return response.data;
};