/*
  Add custom scripts here
*/
import.meta.glob([
  '../assets/img/**',
  // '../assets/json/**',
  '../assets/vendor/fonts/**'
]);

import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

window.Pusher = Pusher;
window.Echo = new Echo({
  broadcaster: 'pusher',
  key: 'your-app-key', // Get this from your `.env` file or WebSocket config
  cluster: 'mt1',
  wsHost: window.location.hostname,
  wsPort: 6001, // Default WebSocket port
  forceTLS: false,
  disableStats: true
});

window.Echo.channel('whatsapp-status.' + leadId).listen('status-updated', event => {
  console.log(event); // Handle the event here, such as updating the UI with the message status
});
