@extends('layouts/layoutMaster')

@section('title', 'Daily Accounts')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection


@section('content')
<!-- Users List Table -->
<div class="card">
  @php
    $helper = new \App\Helpers\Helpers();
    $common_date_format = $helper->general_setting_data()->date_format ?? 'd-M-y';
  @endphp
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">Daily Accounts</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-chevron-double-right fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Accounts Management</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
      <!-- <div class="btn-group dropstart"> -->
      <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" title="Exports">
        <span><i class="mdi mdi-export text-center"></i></span>
      </a>
      <div class="btn-group">
        <button type="button" class="btn btn-sm fw-bold btn-primary dropdown-toggle hide-arrow" id="accounts_filter" title="Filter">
          <i class="mdi mdi-filter-outline text-center"></i>
        </button>
        <!-- <div class="dropdown-menu dropdown-menu-end dropdown-menu-xxl-start p-6 text-muted" style="width: 500px;">
          <p>Some example text that's free-flowing within the dropdown menu.</p>
          <p class="mb-0">And this is more example text.</p>
        </div> -->
      </div>
      @if(auth()->user()->hasPermission('Accounts Management', 'Add account', 'Daily Accounts'))
      <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#kt_modal_add_daily_accounts" class="btn btn-sm fw-bold btn-primary">
        <span class="me-2"><i class="mdi mdi-plus"></i></span>Add Daily Accounts
      </a>
      @endif
    </div>
    <div class="accounts_filter" style="display: none;">
      <form id="filter_form" method="POST" action="{{ route('account_filter') }}" autocomplete="off">
        @csrf
        <div class="row py-1">
          <div class="col-lg-3 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger</label>
            <select id="ledger_fill" name="ledger_fill" class="select3 form-select" onchange="get_sub_ledger_filter(this.value)">
              <option value="">Select Ledger</option>
              @foreach ($ledger_list as $ld_list)
              <option value="{{ $ld_list->sno }}" @if($ld_list->sno==
                $ledger_fill)
                selected @endif>{{ $ld_list->ledger_name }}</option>
              @endforeach

            </select>
          </div>
          <div class="col-lg-3 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger</label>
            <select id="sub_ledger_fill" name="sub_ledger_fill" class="select3 form-select">
            </select>
          </div>
          <div class="col-lg-3 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Account</label>
            <input type="text" class="form-control" id="ledger_acc_fill" name="ledger_acc_fill" placeholder="Enter Ledger Account" value="{{ $ledger_acc_fill ?? '' }}"/>
          </div>
          <div class="col-lg-3 mb-2">
            <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
            <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
                <option value="all" @if($date_filter =="all") selected @endif>All</option>
                <option value="today"  @if($date_filter =="today")selected @endif>Today</option>
                <option value="week"  @if($date_filter =="week") selected @endif>This Week</option>
                <option value="monthly"  @if($date_filter =="monthly") selected @endif>This Month</option>
                <option value="custom_date"  @if($date_filter =="custom_date") selected @endif>Custom Date</option>
            </select>
          </div>
          <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_acc_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
            </div>
          </div>
          <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_acc_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
            </div>
          </div>
          <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_acc_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
            </div>
          </div>
          <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_acc_month_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
            </div>
          </div>
          <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_from_dt_fill" readonly name="from_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
            </div>
          </div>
          <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
            <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
              <input type="text" id="acc_daily_to_dt_fill" readonly name="to_date_fillter_textbox" placeholder="Select Date" class="form-control common_date_class" value="<?php echo date("d-M-Y"); ?>" />
            </div>
          </div>
        </div>
        <div class="d-flex justify-content-end mb-2">
          <a href="{{ url('/accounts/daily_accounts') }}" type="button"
              class="me-2 btn btn-sm btn-secondary fw-semibold fs-6">Reset
          </a>
          <button type="submit" class="btn btn-sm btn-primary fw-semibold fs-6">Go</button>
        </div>
      </form>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-80px">Date</th>
              <th class="min-w-100px">Ledger / Sub Ledger</th>
              <th class="min-w-100px">Ledger Account</th>
              <th class="min-w-80px">Credit</th>
              <th class="min-w-80px">Debit</th>
              <th class="min-w-80px">Tax</th>
              <th class="min-w-50px"><span class="text-end">Actions</span></th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            @if (isset($trans_list))
            @foreach ($trans_list as $list)
            <tr>
              <td>{{ date($common_date_format,strtotime($list->transaction_date)) }}</td>
              <td>
                <span class="text-dark fs-7">{{ $list->ledger_name }}</span>
                <span class="d-block text-gray-600 fs-8">{{ $list->subledger_name }}</span>
              </td>
              <td>
                <label>{{ $list->transaction_name??'-' }}</label>
                <a href="javascipt:;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="{{ $list->trans_desc ??'-' }}"><i class="mdi mdi mdi-help-circle text-dark"></i></a>
              </td>
              <td align="right">
                @if($list->credit>0)
                <label class="badge bg-success text-white">
                  <span class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-white"></i></span>
                  <span class="fs-7">{{ number_format($list->credit ?? 0, 2, '.', ',') }}</span>
                </label>
                @else
                <label>
                  -
                </label>
                @endif
							</td>
              <td align="right">
                @if($list->debit>0)
                <label class="badge bg-danger text-white">
                  <span class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-white"></i></span>
                  <span class="fs-6">{{ number_format($list->debit ?? 0, 2, '.', ',') }}</span>
                </label>
                @else
                <label>
                  -
                </label>
                @endif
              </td>
              <td align="right">
                @if($list->credit>0)
                <label class="badge bg-warning text-black">
                  <span class="fs-7"><i class="mdi mdi-currency-rupee fs-7 text-black"></i></span>
                  <span class="fs-7">{{ number_format($list->tax ?? 0, 2, '.', ',') }}</span>
                </label>
                @else
                <label>
                  -
                </label>
                @endif
							</td>
              <td>
                <span class="text-end">
                  @if(auth()->user()->hasPermission('Accounts Management', 'Edit', 'Daily Accounts'))
                  @if($list->daily_acc_chk == 1)
                  <a href="#" class="btn btn-icon btn-sm me-2" data-bs-toggle="modal" data-bs-target="#kt_modal_edit_daily_accounts" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"onclick="EditModal('{{ $list->sno }}')"  >
                    <i class="mdi mdi-square-edit-outline fs-3 text-black"></i>
                  </a>
                  @endif
                  @endif
                  @if(auth()->user()->hasPermission('Accounts Management', 'Delete', 'Daily Accounts'))
                  <a href="javascript:;" class="btn btn-icon btn-sm" style="display:none!important"  data-bs-toggle="modal" onclick="confirmDelete('{{ $list->sno }}', '{{ $list->transaction_name }}', '{{ $list->transaction_id }}')" data-bs-target="#kt_modal_delete_daily_accounts" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete" >
                    <i class="mdi mdi-delete-outline fs-3 text-black"></i>
                  </a>
                  @endif
                </span>
              </td>
            </tr>
            @endforeach
            @endif

          </tbody>
          <!--end::Table body-->
          <tfoot>
            <tr class="text-start align-top fw-bold fs-5 gs-0">
              <th class="min-w-100px text-end text-black fw-bold fs-5" colspan="3">Total</th>
              <th class="min-w-80px text-end">
                <label class="badge bg-success text-white">
                  <span class="fs-6"><i class="mdi mdi-currency-rupee fs-6 text-white"></i></span>
                  <span class="fs-6">{{ number_format($sum_credit->total_credit ?? 0, 2, '.', ',') }}</span>
                </label>
              </th>
              <th class="min-w-80px text-end">
                <label class="badge bg-danger text-white">
                  <span class="fs-6"><i class="mdi mdi-currency-rupee fs-6 text-white"></i></span>
                  <span class="fs-6">{{ number_format($sum_debit->total_debit ?? 0, 2, '.', ',') }}</span>
                </label>
              </th>
              <th class="min-w-80px text-end">
                <label class="badge bg-warning text-black">
                  <span class="fs-6"><i class="mdi mdi-currency-rupee fs-6 text-black"></i></span>
                  <span class="fs-6">{{ number_format($sum_tax->total_tax ?? 0, 2, '.', ',') }}</span>
                </label>
              </th>
              <th class="min-w-50px"><span class="text-end"></span></th>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </div>
</div>


<!--begin::Modal - Add Daily Accounts-->
<div class="modal fade" id="kt_modal_add_daily_accounts" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Create Daily Accounts</h3>
        </div>
        <form id="validationForm" class="needs-validation" method="POST" action="{{ route('add_daily_accounts') }}"
        onsubmit="return AddvalidateForm()" autocomplete="off">
        @csrf
          <div class="row">
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Ledger<span class="text-danger">*</span></label>
              <select id="ledger_id_add" name="ledger_id_add" class="select3 form-select" onchange="get_sub_ledger(this.value)">
                <option value="">Select Ledger</option>
                @foreach ($ledger_list as $ld_list)
                <option value="{{ $ld_list->sno }}">{{ $ld_list->ledger_name }}</option>
                @endforeach

              </select>
              <div class="text-danger" id="ledger_id_add_err"></div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger<span class="text-danger">*</span></label>
              <select id="subledger_id_add" name="subledger_id_add" class="select3 form-select">
                <option value="">Select Sub Ledger</option>
              </select>
              <div class="text-danger" id="subledger_id_add_err"></div>
            </div>
            <div class="col-lg-4 mb-3 d-flex align-items-center justify-content-start">
              <div class="form-check form-check-inline mt-4">
                <input class="form-check-input trans_type" type="radio" name="cr_dr" id="credit" value="Credit" checked onclick="check_cr_db()"/>
                <label class="form-check-label" for="inlineRadio1">Credit</label>
              </div>
              <div class="form-check form-check-inline mt-4">
                <input class="form-check-input trans_type" type="radio" name="cr_dr" id="debit" value="Debit" onclick="check_cr_db()"/>
                <label class="form-check-label" for="inlineRadio1">Debit</label>
              </div>
            </div>
            <div class="col-lg-8 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Account<span class="text-danger">*</span></label>
              <div style="position: relative; width: 100%;">
                  <input type="text" class="form-control" id="trans_source_id" name="trans_source_id" autocomplete="off" placeholder="Type to search ledger account" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                  <span id="result-list" style="position: absolute; width: 100%; background-color: white; border: 1px solid #ddd; max-height: 150px; overflow-y: auto; display: none;"></span>
                  <div class="text-danger" id="search_err"></div>
              </div>
            </div>
            <div class="col-lg-4 mb-3 d-flex align-items-center justify-content-start">
              <div class="align-items-center me-2">
                <div class="fs-6 fw-bold mb-1 text-success text-center">Cr (+)</div>
                <div class="d-block fw-bold mb-1">
                  <label class="badge bg-success rounded text-white fs-6">
                    <span id="credit_amount_label">0.00</span>
                  </label>
                </div>
              </div>
              <div class="d-block align-items-center text-danger">
                <div class="fs-6 fw-bold mb-1 text-center">Dr (-)</div>
                <div class="d-block fw-bold mb-1">
                  <label class="badge bg-danger rounded text-white fs-6">
                    <span id="debit_amount_label">0.00</span>
                  </label>
                </div>
              </div>
            </div>
            <div class="col-lg-4 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
              <input type="text" class="form-control" id="ledger_amount_add" name="ledger_amount_add" placeholder="Enter Amount" onkeyup="check_cr_db()" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
              <div class="text-danger" id="ledger_amount_add_err"></div>
            </div>
            <div class="col-lg-8 mb-3">
              <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
              <textarea class="form-control" rows="1" id="daily_desc" name="daily_desc" placeholder="Enter Description"></textarea>
            </div>
          </div>
          <div class="d-flex justify-content-end align-items-center mt-4">
            <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary" >Create Daily Accounts</button>
          </div>
        </form>

      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Add Daily Accounts-->

<!--begin::Modal - Edit Daily Accounts-->
<div class="modal fade" id="kt_modal_edit_daily_accounts" tabindex="-1" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-xl">
    <!--begin::Modal content-->
    <div class="modal-content rounded">
      <!--begin::Modal header-->
      <div class="modal-header justify-content-end border-0 pb-0">
        <!--begin::Close-->
        <div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
          <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
          <span class="svg-icon svg-icon-1">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="currentColor" />
              <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="currentColor" />
            </svg>
          </span>
          <!--end::Svg Icon-->
        </div>
        <!--end::Close-->
      </div>
      <!--end::Modal header-->
      <!--begin::Modal body-->
      <div class="modal-body pt-0 pb-10 px-10 px-xl-20">
        <!--begin::Heading-->
        <div class="mb-4 text-center">
          <h3 class="text-center mb-4 text-black">Update Daily Accounts</h3>
        </div>
        <form id="validationForm" class="needs-validation" method="POST" action="{{ route('update_daily_accounts') }}"
          onsubmit="return EditvalidateForm()" autocomplete="off">
          @csrf
          <div class="row">
              <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Ledger<span class="text-danger">*</span></label>
                  <select id="ledger_id_edit" name="ledger_id_edit" class="select3 form-select" onchange="get_sub_ledger_edit(this.value)">
                      <option value="">Select Ledger</option>
                      @foreach ($ledger_list as $ld_list)
                      <option value="{{ $ld_list->sno }}">{{ $ld_list->ledger_name }}</option>
                      @endforeach

                  </select>
                  <div class="text-danger" id="ledger_id_edit_err"></div>
              </div>
              <input type="hidden" name="edit_id" id="edit_id">
              <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger<span class="text-danger">*</span></label>
                  <select id="subledger_id_edit" name="subledger_id_edit" class="select3 form-select">
                      <option value="">Select Sub Ledger</option>
                  </select>
                  <div class="text-danger" id="subledger_id_edit_err"></div>
              </div>
              <div class="col-lg-4 mb-3 d-flex align-items-center justify-content-start">
                  <div class="form-check form-check-inline mt-4">
                      <input class="form-check-input trans_type" type="radio" name="cr_dr_edit" id="credit_edit" value="Credit" checked onclick="check_cr_db_edit()" />
                      <label class="form-check-label" for="inlineRadio1">Credit</label>
                  </div>
                  <div class="form-check form-check-inline mt-4">
                      <input class="form-check-input trans_type" type="radio" name="cr_dr_edit" id="debit_edit" value="Debit" onclick="check_cr_db_edit()" />
                      <label class="form-check-label" for="inlineRadio1">Debit</label>
                  </div>
              </div>
              <div class="col-lg-8 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Account <span class="text-danger">*</span></label>
                  <div style="position: relative; width: 100%;">
                      <input type="text" class="form-control" id="trans_source_id_edit" autocomplete="off" name="trans_source_id_edit" placeholder="Type to search ledger account" oninput="this.value = this.value.replace(/^\w/, function(txt) { return txt.toUpperCase(); });">
                      <span id="result-list_edit" style="position: absolute; width: 100%; background-color: white; border: 1px solid #ddd; max-height: 150px; overflow-y: auto; display: none;"></span>
                      <div class="text-danger" id="search_edit_err"></div>
                  </div>
              </div>
              <div class="col-lg-4 mb-3 d-flex align-items-center justify-content-start">
                  <div class="align-items-center me-2">
                      <div class="fs-6 fw-bold mb-1 text-success text-center">Cr (+)</div>
                      <div class="d-block fw-bold mb-1">
                          <label class="badge bg-success rounded text-white fs-6">
                              <span id="credit_amount_label_edit">0.00</span>
                          </label>
                      </div>
                  </div>
                  <div class="d-block align-items-center text-danger">
                      <div class="fs-6 fw-bold mb-1 text-center">Dr (-)</div>
                      <div class="d-block fw-bold mb-1">
                          <label class="badge bg-danger rounded text-white fs-6">
                              <span id="debit_amount_label_edit">0.00</span>
                          </label>
                      </div>
                  </div>
              </div>
              <div class="col-lg-4 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Amount<span class="text-danger">*</span></label>
                  <input type="text" class="form-control" id="ledger_amount_edit" name="ledger_amount_edit" placeholder="Enter Amount" onkeyup="check_cr_db_edit()" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" maxlength="10" />
                  <div class="text-danger" id="ledger_amount_edit_err"></div>
              </div>
              <div class="col-lg-8 mb-3">
                  <label class="text-dark mb-1 fs-6 fw-semibold">Description</label>
                  <textarea class="form-control" rows="1" id="daily_desc_edit" name="daily_desc_edit" placeholder="Enter Description"></textarea>
              </div>
          </div>
          <div class="d-flex justify-content-end align-items-center mt-4">
              <button type="reset" class="btn btn-secondary me-3" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-primary">Update Daily Accounts</button>
          </div>
      </form>
      </div>
      <!--end::Modal body-->
    </div>
    <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Edit Daily Accounts-->

<!--begin::Modal - Delete Courses-->
<div class="modal fade" id="kt_modal_delete_daily_accounts" tabindex="-1" aria-hidden="true" aria-hidden="true" data-bs-keyboard="false" data-bs-backdrop="static">
  <!--begin::Modal dialog-->
  <div class="modal-dialog modal-m">
      <!--begin::Modal content-->
      <div class="modal-content rounded">
          <div class="swal2-icon swal2-danger swal2-icon-show" style="display: flex;">
              <div class="swal2-icon-content">?</div>
          </div>
          <div class="swal2-html-container" id="swal2-html-container" style="display: block;"> <span id="delete_message"></span></div>
          <div class="d-flex justify-content-center align-items-center pt-8">
              <button type="submit" class="btn btn-danger me-3" onclick="deletedaily_account()">Yes,
                  delete!</button>
              <button type="reset" class="btn btn-secondary" data-bs-dismiss="modal">No,cancel</button>
          </div><br><br>
      </div>
      <!--end::Modal content-->
  </div>
  <!--end::Modal dialog-->
</div>
<!--end::Modal - Delete Courses-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <style>
        /* Customize Toastr container */
        .toast {
            background-color: #39484f;
        }

        /* Customize Toastr notification */
        .toast-success {
            background-color: green;
        }

        /* Customize Toastr notification */
        .toast-error {
            background-color: red;
        }

        .error_msg {
            border: solid 2px red !important;
            border-color: red !important;
        }
    </style>


    {{-- filter --}}
    <script>
      function date_fill_issue_rpt() {
          var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
          var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
          var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
          var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
          var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
          var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
          var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
          var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
          var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');
  
          if (dt_fill_issue_rpt == "today") {
              today_dt_iss_rpt.style.display = "block";
              monthly_dt_iss_rpt.style.display = "none";
              from_dt_iss_rpt.style.display = "none";
              to_dt_iss_rpt.style.display = "none";
              week_from_dt_iss_rpt.style.display = "none";
              week_to_dt_iss_rpt.style.display = "none";
          } else if (dt_fill_issue_rpt == "week") {
              today_dt_iss_rpt.style.display = "none";
              week_from_dt_iss_rpt.style.display = "block";
              week_to_dt_iss_rpt.style.display = "block";
              monthly_dt_iss_rpt.style.display = "none";
              from_dt_iss_rpt.style.display = "none";
              to_dt_iss_rpt.style.display = "none";
  
              var curr = new Date; // get current date
              var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
              var last = first + 6; // last day is the first day + 6
  
              var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
              firstday = firstday.split("-").reverse().join("-");
              var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
              lastday = lastday.split("-").reverse().join("-");
              $('#acc_daily_acc_week_st_dt_fill').val(firstday);
              $('#acc_daily_acc_week_ed_dt_fill').val(lastday);
  
          } else if (dt_fill_issue_rpt == "monthly") {
              today_dt_iss_rpt.style.display = "none";
              monthly_dt_iss_rpt.style.display = "block";
              from_dt_iss_rpt.style.display = "none";
              to_dt_iss_rpt.style.display = "none";
              week_from_dt_iss_rpt.style.display = "none";
              week_to_dt_iss_rpt.style.display = "none";
          } else if (dt_fill_issue_rpt == "custom_date") {
              today_dt_iss_rpt.style.display = "none";
              monthly_dt_iss_rpt.style.display = "none";
              from_dt_iss_rpt.style.display = "block";
              to_dt_iss_rpt.style.display = "block";
              week_from_dt_iss_rpt.style.display = "none";
              week_to_dt_iss_rpt.style.display = "none";
          } else {
              today_dt_iss_rpt.style.display = "none";
              monthly_dt_iss_rpt.style.display = "none";
              from_dt_iss_rpt.style.display = "none";
              to_dt_iss_rpt.style.display = "none";
              week_from_dt_iss_rpt.style.display = "none";
              week_to_dt_iss_rpt.style.display = "none";
          }
      }
    </script>

    <script>
      // Check if 'filter_on' session variable is set and trigger click event
          $(document).ready(function() {
              @if ($filter_on ?? '')
                  $('.accounts_filter').slideToggle('fast');
                  // });
              @endif
          });

          // Toggle branch filter section
          $('#accounts_filter').click(function() {
              $('.accounts_filter').slideToggle('slow');
          });

          document.getElementById('filter_form').onsubmit = function() {
              this.querySelector('button[type="submit"]').disabled = true;
          };
    </script>



<script>
  get_sub_ledger_filter({{ $ledger_fill }})

  function get_sub_ledger_filter(value) {

      // Make AJAX request
      $.ajax({
          url: "{{ route('subledger_list') }}",
          type: "GET",
          data: {
              id: value
          },
          success: function(response) {
              if (response.status === 200 && response.data) {
                  var selectDropdown = $('select[name="sub_ledger_fill"]');
                  selectDropdown.empty();
                  selectDropdown.append($('<option value="">Select Sub Ledger</option>'));
                  response.data.forEach(function(subled) {
                      selectDropdown.append($('<option></option>').attr('value', subled
                          .sno).text(subled.subledger_name));
                          $("#sub_ledger_fill").val({{ $sub_ledger_fill }}).change();
                  });
              }
          },
          error: function(error) {
              // console.error('Error fetching course sub categories:', error);
          }
      });
  };
</script>

    {{-- filter --}}

    <script>
        // Display Toastr messages
        @if (Session::has('toastr'))
            var type = "{{ Session::get('toastr')['type'] }}";
            var message = "{{ Session::get('toastr')['message'] }}";
            toastr[type](message);
        @endif
    </script>

    <script>
      function check_cr_db_edit() {
          var led_amt = parseFloat($('#ledger_amount_edit').val()) || 0; // Ensure it's a float for currency
          var check = $('[name="cr_dr_edit"]:checked').val(); // Get the selected radio button value

          // Format the amount in Indian currency format (INR)
          var amt = led_amt.toLocaleString('en-IN', {
              minimumFractionDigits: 2, // Ensures it always shows two decimal places
              maximumFractionDigits: 2,
              style: 'currency',
              currency: 'INR'
          });

          if (check === 'Credit') {
              $('#credit_amount_label_edit').html(amt);
              $('#debit_amount_label_edit').html('₹0.00'); // Reset debit with currency formatting
          } else if (check === 'Debit') {
              $('#debit_amount_label_edit').html(amt);
              $('#credit_amount_label_edit').html('₹0.00'); // Reset credit with currency formatting
          } else {
              // If no radio button is selected, reset both labels
              $('#credit_amount_label_edit').html('₹0.00');
              $('#debit_amount_label_edit').html('₹0.00');
          }
      }
    </script>

    <script>
      function EditModal(sno) {
          fetch(`/edit_daily_accounts/${sno}`)
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      const edit_account = data.data;
                      var type = edit_account.transaction_type;

                      // Check the corresponding radio button
                      if (type === 'Credit') {
                          $('#credit_edit').prop('checked', true);
                      } else if (type === 'Debit') {
                          $('#debit_edit').prop('checked', true);
                      }

                      // Set the value of ledger ID and trigger the change event if necessary
                      $('#ledger_id_edit').val(edit_account.ledger_id).change();
                      setTimeout(() => {
                      $('#subledger_id_edit').val(edit_account.subledger_id).change();
                      }, 500);
                      var search_name = edit_account.transaction_name +' - '+ edit_account.trans_source_id;
                      $('#search_edit').val(search_name);
                      $('#edit_id').val(edit_account.sno);
                      $('#ledger_amount_edit').val(edit_account.total_amount);
                      $('#daily_desc_edit').val(edit_account.trans_desc);
                      check_cr_db_edit()

                  } else {
                      console.error('Error fetching ledger:', data.message);
                  }
              })
              .catch(error => {
                  console.error('Error fetching ledger:', error);
              });
      }
    </script>


    <script>
      function confirmDelete(id, name, ids) {
          document.querySelector('#kt_modal_delete_daily_accounts .btn-danger').setAttribute(
              'data-id', id);
              $('#delete_message').html('Are you sure you want to delete  Daily Accounts<br> <b> [ <span class="text-danger">' + ids + '</span> ] - ' + name + ' </b> ?');
      }
      function deletedaily_account() {
          var sno = document.querySelector('#kt_modal_delete_daily_accounts .btn-danger').getAttribute(
              'data-id');

          fetch('/delete_daily_accounts/' + categoryId, {
                  method: 'DELETE'
                  , headers: {
                      'Content-Type': 'application/json'
                      , 'X-CSRF-TOKEN': '{{ csrf_token() }}' // Include CSRF token if using Laravel CSRF protection
                  }
              })
              .then(response => response.json())
              .then(data => {
                  if (data.status === 200) {
                      toastr.success(data.message);
                      location.reload();
                  } else {
                      toastr.error(data.error_msg);
                      console.error(data.error_msg);
                  }
              })
              .catch(error => {
                  console.error('Error:', error);
              });
      }
    </script>

    <script>
      function EditvalidateForm() {
          // Get form elements
          var err = 0;
          const ledgerId = document.getElementById('ledger_id_edit').value;
          const subledgerId = document.getElementById('subledger_id_edit').value;
          const transSourceId = document.getElementById('trans_source_id_edit').value;
          const amount = document.getElementById('ledger_amount_edit').value.trim();
          // Check required fields
          if (ledgerId === '') {
              $('#ledger_id_edit_err').html('Select Ledger is Required.');
              err++;
          } else {
              $('#ledger_id_edit_err').html('');
          }
          if (subledgerId === '') {
              $('#subledger_id_edit_err').html('Select Sub Ledger is Required.');
              err++;
          } else {
              $('#subledger_id_edit_err').html('');
          }
          if (transSourceId === '') {
              $('#search_edit_err').html('Select a Ledger Account is Required.');
              err++;
          } else {
              $('#search_edit_err').html('');
          }
          if (amount === '' || isNaN(amount) || parseFloat(amount) <= 0) {
              $('#ledger_amount_edit_err').html('Enter a valid amount greater than 0.');
              err++;
          } else {
              $('#ledger_amount_edit_err').html('');
          }
          // All validations passed
          return err === 0;
      }
    </script>

    <script type="text/javascript">
      $(document).ready(function() {
          $('#search_edit').on('keyup', function() {
              var query = $(this).val();
              // alert(query);
              if (query.length > 2) {
                  $.ajax({
                      url: "{{ route('autocomplete_daily_acounts') }}",
                      type: "GET",
                      data: {
                          'term': query
                      },
                      success: function(data) {
                          $('#result-list_edit').empty().show();
                          if (data.length > 0) {
                              $.each(data, function(index, value) {
                                  $('#result-list_edit').append('<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' + value.cus_name + ' - ' + value.customer_id + '</p>');
                                  $('#search_edit_err').html('');
                              });
                          } else {
                              $('#search_edit_err').html('No Record Found or Invalid Ledger Account');
                          }
                      }
                  });
              } else {
                  $('#result-list_edit').hide();
              }
          });

          // Handle selection from the list
          $(document).on('click', '#result-list_edit p', function() {
              var selectedText = $(this).text();
              $('#search_edit').val(selectedText);
              $('#result-list_edit').hide(); // Hide the list after selection
          });
      });
    </script>

    <script>
      function get_sub_ledger_edit(value) {

          // Make AJAX request
          $.ajax({
              url: "{{ route('subledger_list') }}",
              type: "GET",
              data: {
                  id: value
              },
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      var selectDropdown = $('#subledger_id_edit');
                      selectDropdown.empty();
                      selectDropdown.append($('<option value="">Select Sub Ledger</option>'));
                      response.data.forEach(function(subled) {
                          selectDropdown.append($('<option></option>').attr('value', subled
                              .sno).text(subled.subledger_name));
                      });
                  }
              },
              error: function(error) {
                  // console.error('Error fetching course sub categories:', error);
              }
          });
      };
    </script>

    <script>
      function AddvalidateForm() {
        // Get form elements
        var err = 0;
        const ledgerId = document.getElementById('ledger_id_add').value;
        const subledgerId = document.getElementById('subledger_id_add').value;
        const transSourceId = document.getElementById('trans_source_id').value;
        const amount = document.getElementById('ledger_amount_add').value.trim();
        // Check required fields
        if (ledgerId === '') {
            $('#ledger_id_add_err').html('Select Ledger is Required.');
            err++;
        }else{
          $('#ledger_id_add_err').html('');
        }
        if (subledgerId === '') {
          $('#subledger_id_add_err').html('Select Sub Ledger is Required.');
            err++;
        }else{
          $('#subledger_id_add_err').html('');
        }
        if (transSourceId === '') {
            $('#search_err').html('Select a Ledger Account is Required.');
            err++;
        }else{
          $('#search_err').html('');
        }
        if (amount === '' || isNaN(amount) || parseFloat(amount) <= 0) {
            $('#ledger_amount_add_err').html('Enter a valid amount greater than 0.');
            err++;
        }else{
          $('#ledger_amount_add_err').html('');
        }
        // All validations passed
        return err===0;
      }
    </script>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#search').on('keyup', function() {
                var query = $(this).val();
                // alert(query);
                if (query.length > 2) {
                    $.ajax({
                        url: "{{ route('autocomplete_daily_acounts') }}",
                        type: "GET",
                        data: {'term': query},
                        success: function(data) {
                            $('#result-list').empty().show();
                            if (data.length > 0) {
                                $.each(data, function(index, value) {
                                    $('#result-list').append('<p style="padding: 5px; cursor: pointer;" class="bg-secondary text-white mb-2 ms-2 me-2 mt-2">' + value.cus_name + ' - ' + value.customer_id +'</p>');
                                    $('#search_err').html('');
                                });
                            } else {
                                $('#search_err').html('No Record Found or Invalid Ledger Account');
                            }
                        }
                    });
                } else {
                    $('#result-list').hide();
                }
            });

            // Handle selection from the list
            $(document).on('click', '#result-list p', function() {
                var selectedText = $(this).text();
                $('#search').val(selectedText);
                $('#result-list').hide(); // Hide the list after selection
            });
        });
    </script>

    <script>
      check_cr_db()
      function check_cr_db() {
          var led_amt = parseFloat($('#ledger_amount_add').val()) || 0; // Ensure it's a float for currency
          var check = $('[name="cr_dr"]:checked').val(); // Get the selected radio button value

          // Format the amount in Indian currency format (INR)
          var amt = led_amt.toLocaleString('en-IN', {
              minimumFractionDigits: 2, // Ensures it always shows two decimal places
              maximumFractionDigits: 2,
              style: 'currency',
              currency: 'INR'
          });

          if (check === 'Credit') {
              $('#credit_amount_label').html(amt);
              $('#debit_amount_label').html('₹0.00'); // Reset debit with currency formatting
          } else if (check === 'Debit') {
              $('#debit_amount_label').html(amt);
              $('#credit_amount_label').html('₹0.00'); // Reset credit with currency formatting
          } else {
              // If no radio button is selected, reset both labels
              $('#credit_amount_label').html('₹0.00');
              $('#debit_amount_label').html('₹0.00');
          }
      }


    </script>

    <script>
      function get_sub_ledger(value) {

          // Make AJAX request
          $.ajax({
              url: "{{ route('subledger_list') }}",
              type: "GET",
              data: {
                  id: value
              },
              success: function(response) {
                  if (response.status === 200 && response.data) {
                      var selectDropdown = $('select[name="subledger_id_add"]');
                      selectDropdown.empty();
                      selectDropdown.append($('<option value="">Select Sub Ledger</option>'));
                      response.data.forEach(function(subled) {
                          selectDropdown.append($('<option></option>').attr('value', subled
                              .sno).text(subled.subledger_name));
                      });
                  }
              },
              error: function(error) {
                  // console.error('Error fetching course sub categories:', error);
              }
          });
      };
    </script>

    <script>
      $(".list_page").DataTable({
        "ordering": false,
        // "aaSorting":[],
        "language": {
          "lengthMenu": "Show _MENU_",
        },
        "dom": "<'row mb-3'" +
          "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
          "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
          ">" +

          "<'table-responsive'tr>" +

          "<'row'" +
          "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
          "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
          ">"
      });
    </script>


@endsection
