@extends('layouts/layoutMaster')

@section('title', 'Profit & Loss')

@section('vendor-style')
@vite([
'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
'resources/assets/vendor/libs/select2/select2.scss',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.scss',
'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
@endsection

@section('vendor-script')
@vite([
'resources/assets/vendor/libs/select2/select2.js',
'resources/assets/vendor/libs/bootstrap-datepicker/bootstrap-datepicker.js',
'resources/assets/vendor/js/dropdown-hover.js',
'resources/assets/vendor/libs/flatpickr/flatpickr.js'
])
@endsection

@section('page-script')
@vite(['resources/assets/js/forms_date_time_pickers.js'])
@endsection

@section('content')
<!-- Users List Table -->
<div class="card">
  <div class="card-header border-bottom pb-1">
    <h5 class="card-title mb-1">Profit & Loss</h5>
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="{{url('/dashboards')}}" class="d-flex align-items-center"><i class="mdi mdi-home text-body fs-4"></i></a>
        </li>
        <span class="text-dark opacity-75 me-1 ms-1">
          <i class="mdi mdi-chevron-double-right fs-4"></i>
        </span>
        <li class="breadcrumb-item">
          <a href="javascript:;" class="d-flex align-items-center">Accounts Management</a>
        </li>
      </ol>
    </nav>
  </div>
  <div class="card-body">
    <div class="d-flex justify-content-end align-items-center mb-2 gap-1">
      <!-- <div class="btn-group dropstart"> -->
      {{-- <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" title="Exports">
        <span><i class="mdi mdi-export text-center"></i></span>
      </a> --}}
      <div class="btn-group">
        {{-- <button type="button" class="btn btn-sm fw-bold btn-primary dropdown-toggle hide-arrow" id="filter" title="Filter">
          <i class="mdi mdi-filter-outline text-center"></i>
        </button> --}}
        <!-- <div class="dropdown-menu dropdown-menu-end dropdown-menu-xxl-start p-6 text-muted" style="width: 500px;">
          <p>Some example text that's free-flowing within the dropdown menu.</p>
          <p class="mb-0">And this is more example text.</p>
        </div> -->
      </div>
    </div>
    <div class="filter_tbox" style="display: none;">
      <div class="row py-1">
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Ledger</label>
          <select id="" class="select3 form-select">
            <option value="">All</option>
            <option value="1">Expense</option>
            <option value="2">Income</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Sub Ledger</label>
          <select id="" class="select3 form-select">
            <option value="">All</option>
            <option value="1">Insurance Expense</option>
            <option value="2">Rent Expense</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Ledger Account</label>
          <input type="text" class="form-control" id="" placeholder="Enter Ledger Account" />
        </div>
        <div class="col-lg-3 mb-2">
          <label class="text-dark mb-1 fs-6 fw-semibold">Date</label>
          <select class="select3 form-select" name="dt_fill_issue_rpt" id="dt_fill_issue_rpt" onchange="date_fill_issue_rpt();">
            <option value="all">All</option>
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="monthly">This Month</option>
            <option value="custom_date">Custom Date</option>
          </select>
        </div>
        <div class="col-lg-3 mb-2" id="today_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Today</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_acc_today_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_from_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">Start Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_acc_week_st_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="week_to_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">End Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text bg-gray-200"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_acc_week_ed_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" disabled />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="monthly_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">This Month</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_acc_month_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="from_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">From Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_from_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
        <div class="col-lg-3 mb-2" id="to_dt_iss_rpt" style="display: none;">
          <label class="text-dark mb-1 fs-6 fw-semibold">To Date</label>
          <div class="input-group input-group-merge">
            <span class="input-group-text"><i class="mdi mdi-calendar-month-outline fs-4"></i></span>
            <input type="text" id="acc_pf_ls_to_dt_fill" placeholder="Select Date" class="form-control" value="<?php echo date("d-M-Y"); ?>" />
          </div>
        </div>
      </div>
      <div class="d-flex align-items-center justify-content-end mb-2">
        <a href="javascript:;" class="btn btn-sm fw-bold btn-primary" id="filter" title="Filter">Go</a>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-12">
        <table class="table align-middle table-row-dashed table-striped table-hover gy-0 gs-1 list_page">
          <thead>
            <tr class="text-start align-top fw-bold fs-6 gs-0 bg-primary">
              <th class="min-w-200px">Income</th>
              <th class="min-w-100px text-center">Amount</th>
              <th class="min-w-200px">Expense</th>
              <th class="min-w-100px text-center">Amount</th>
            </tr>
          </thead>
          <tbody class="text-black fw-semibold fs-7">
            <tr>
              <td>{{ $ledger_list[0]->ledger_name}}</td>
              <td align="right">
                <label class="badge bg-success text-white">
                  <span class="fs-7"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                  <span class="fs-7">{{ number_format($sum_credit->total_credit ?? 0, 2, '.', ',')   }}</span>
                </label>
              </td>
              <td>{{ $ledger_list[1]->ledger_name}}</td>
              <td align="right">
                <label class="badge bg-danger text-white">
                  <span class="fs-7"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                  <span class="fs-7">{{number_format($sum_debit->total_debit ?? 0, 2, '.', ',')  }}</span>
                </label>
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr class="text-start align-top fw-bold fs-5 gs-0">
              <th class="min-w-200px text-end fw-bold fs-5 text-black">Total Income (A)</th>
              <th class="min-w-100px text-end">
                <label class="badge bg-success text-white">
                  <span class="fs-5"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                  <span class="fs-5">{{number_format($sum_credit->total_credit ?? 0, 2, '.', ',')  }}</span>
                </label>
              </th>
              <th class="min-w-200px text-end fw-bold fs-5 text-black">Total Expenses (B)</th>
              <th class="min-w-100px text-end">
                <label class="badge bg-danger text-white">
                  <span class="fs-5"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                  <span class="fs-5">{{number_format($sum_debit->total_debit ?? 0, 2, '.', ',')  }}</span>
                </label>
              </th>
            </tr>
            <tr class="text-start align-top fw-bold fs-5 gs-0">
              <th class="min-w-200px text-center text-black fw-bold fs-5" colspan="3">Net Income (A-B)</th>
              <!-- <th class="min-w-100px text-end">
								<label class="badge bg-danger text-white">
									<span class="fs-4"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
									<span class="fs-4">99,000.00</span>
								</label>
							</th> -->
              <th class="min-w-100px text-end">
                <label class="badge bg-success text-white">
                  <span class="fs-4"><i class="mdi mdi-currency-rupee fs-8 text-white"></i></span>
                  <span class="fs-4">{{number_format($sum_credit->total_credit - $sum_debit->total_debit ?? 0, 2, '.', ',')  }}</span>
                </label>
              </th>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  </div>
</div>


<script>
  $(".list_page").DataTable({
    "ordering": false,
    // "aaSorting":[],
    "language": {
      "lengthMenu": "Show _MENU_",
    },
    "dom": "<'row mb-3'" +
      "<'col-sm-6 d-flex align-items-center justify-conten-start'l>" +
      "<'col-sm-6 d-flex align-items-center justify-content-end'f>" +
      ">" +

      "<'table-responsive'tr>" +

      "<'row'" +
      "<'col-sm-12 col-md-5 d-flex align-items-center justify-content-center justify-content-md-start'i>" +
      "<'col-sm-12 col-md-7 d-flex align-items-center justify-content-center justify-content-md-end'p>" +
      ">"
  });
</script>
<script>
  $('#filter').click(function() {
    $('.filter_tbox').slideToggle('slow');
  });
</script>
<script>
  function date_fill_issue_rpt() {
    var dt_fill_issue_rpt = document.getElementById('dt_fill_issue_rpt').value;
    var today_dt_iss_rpt = document.getElementById('today_dt_iss_rpt');
    var week_from_dt_iss_rpt = document.getElementById('week_from_dt_iss_rpt');
    var week_to_dt_iss_rpt = document.getElementById('week_to_dt_iss_rpt');
    var monthly_dt_iss_rpt = document.getElementById('monthly_dt_iss_rpt');
    var from_dt_iss_rpt = document.getElementById('from_dt_iss_rpt');
    var to_dt_iss_rpt = document.getElementById('to_dt_iss_rpt');
    var from_date_fillter_iss_rpt = document.getElementById('from_date_fillter_iss_rpt');
    var to_date_fillter_iss_rpt = document.getElementById('to_date_fillter_iss_rpt');

    if (dt_fill_issue_rpt == "today") {
      today_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "week") {
      today_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "block";
      week_to_dt_iss_rpt.style.display = "block";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";

      var curr = new Date; // get current date
      var first = curr.getDate() - curr.getDay(); // First day is the day of the month - the day of the week
      var last = first + 6; // last day is the first day + 6

      var firstday = new Date(curr.setDate(first)).toISOString().slice(0, 10);
      firstday = firstday.split("-").reverse().join("-");
      var lastday = new Date(curr.setDate(last)).toISOString().slice(0, 10);
      lastday = lastday.split("-").reverse().join("-");
      $('#week_from_date_fil').val(firstday);
      $('#week_to_date_fil').val(lastday);

    } else if (dt_fill_issue_rpt == "monthly") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "block";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else if (dt_fill_issue_rpt == "custom_date") {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "block";
      to_dt_iss_rpt.style.display = "block";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    } else {
      today_dt_iss_rpt.style.display = "none";
      monthly_dt_iss_rpt.style.display = "none";
      from_dt_iss_rpt.style.display = "none";
      to_dt_iss_rpt.style.display = "none";
      week_from_dt_iss_rpt.style.display = "none";
      week_to_dt_iss_rpt.style.display = "none";
    }
  }
</script>
@endsection
