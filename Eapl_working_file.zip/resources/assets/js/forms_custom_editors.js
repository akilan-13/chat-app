/**
 * Form Editors
 */

'use strict';

(function () {
  // Full Toolbar
  // --------------------------------------------------------------------
  const CreatefullToolbar = [
    [
      {
        font: []
      },
      {
        size: []
      }
    ],
    ['bold', 'italic', 'underline', 'strike'],
    [
      {
        color: []
      },
      {
        background: []
      }
    ],
    [
      {
        script: 'super'
      },
      {
        script: 'sub'
      }
    ],
    [
      {
        header: '1'
      },
      {
        header: '2'
      },
      'blockquote',
      'code-block'
    ],
    [
      {
        list: 'ordered'
      },
      {
        list: 'bullet'
      },
      {
        indent: '-1'
      },
      {
        indent: '+1'
      }
    ],
    [{ direction: 'rtl' }],
    ['link', 'image', 'video', 'formula'],
    ['clean']
  ];
  const CreatefullEditor = new Quill('#create_exam_guideline_editor', {
    bounds: '#create_exam_guideline_editor',
    placeholder: 'Type Something...',
    modules: {
      formula: true,
      toolbar: CreatefullToolbar
    },
    theme: 'snow'
  });

})();
