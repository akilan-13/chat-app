// AjaxCall class for edit functionality
function ajaxCall() {
  this.send = function (data, url, method, success, type) {
    type = 'json';
    var successRes = function (data) {
      success(data);
    };
    var errorRes = function (xhr, ajaxOptions, thrownError) {
      console.log(thrownError + '\r\n' + xhr.statusText + '\r\n' + xhr.responseText);
    };
    jQuery.ajax({
      url: url,
      type: method,
      data: data,
      success: successRes,
      error: errorRes,
      dataType: type,
      timeout: 60000
    });
  };
}

// LocationInfo class for edit functionality
function locationInfoEdit() {
  var rootUrl = 'https://geodata.phplift.net/api/index.php';
  var call = new ajaxCall();
  var isCountryLoading = false;
  var isStateLoading = false;

  this.getCities = function (stateId, selectedCityId) {
    jQuery('#city_edit option:gt(0)').remove();
    var url = rootUrl + '?type=getCities&stateId=' + stateId;
    var method = 'post';
    var data = {};
    jQuery('#city_edit').find('option:eq(0)').html('Please wait..');
    call.send(data, url, method, function (data) {
      jQuery('#city_edit').find('option:eq(0)').html('Select City');
      jQuery.each(data['result'], function (key, val) {
        var option = jQuery('<option></option>');
        option.attr('value', val.id).text(val.name);
        jQuery('#city_edit').append(option);
      });
      jQuery('#city_edit').prop('disabled', false);
      if (selectedCityId) {
        jQuery('#city_edit').val(selectedCityId).trigger('change');
      }
    });
  };

  this.getStates = function (countryId, selectedStateId, selectedCityId) {
    if (isStateLoading) return;
    isStateLoading = true;

    jQuery('#state_edit option:gt(0)').remove();
    jQuery('#city_edit option:gt(0)').remove();
    var url = rootUrl + '?type=getStates&countryId=' + countryId;
    var method = 'post';
    var data = {};
    jQuery('#state_edit').find('option:eq(0)').html('Please wait..');
    call.send(data, url, method, function (data) {
      jQuery('#state_edit').find('option:eq(0)').html('Select State');
      jQuery.each(data['result'], function (key, val) {
        var option = jQuery('<option></option>');
        option.attr('value', val.id).text(val.name);
        jQuery('#state_edit').append(option);
      });
      jQuery('#state_edit').prop('disabled', false);
      if (selectedStateId) {
        jQuery('#state_edit').val(selectedStateId).trigger('change');
        if (selectedCityId) {
          locationInfoEditInstance.getCities(selectedStateId, selectedCityId);
        }
      }
      isStateLoading = false;
    });
  };

  this.getCountries = function (selectedCountryId, selectedStateId, selectedCityId) {
    if (isCountryLoading) return;
    isCountryLoading = true;

    var url = rootUrl + '?type=getCountries';
    var method = 'post';
    var data = {};
    jQuery('#country_edit').find('option:eq(0)').html('Please wait..');
    call.send(data, url, method, function (data) {
      jQuery('#country_edit').find('option:eq(0)').html('Select Country');
      jQuery.each(data['result'], function (key, val) {
        var option = jQuery('<option></option>');
        option.attr('value', val.id).text(val.name);
        jQuery('#country_edit').append(option);
      });
      if (selectedCountryId) {
        jQuery('#country_edit').val(selectedCountryId).trigger('change');
        if (selectedStateId) {
          locationInfoEditInstance.getStates(selectedCountryId, selectedStateId, selectedCityId);
        }
      }
      isCountryLoading = false;
    });
  };
}

var locationInfoEditInstance = new locationInfoEdit();

jQuery(document).ready(function () {
  // Initialize the select2 plugin on the select elements
  $('#countryId, #stateId, #cityId, #country_edit, #state_edit, #city_edit').select2();

  jQuery('#country_edit').on('change', function (ev) {
    var countryId = jQuery(this).val();
    if (countryId != '') {
      locationInfoEditInstance.getStates(countryId, null, null);
    } else {
      jQuery('#state_edit option:gt(0)').remove();
    }
  });

  jQuery('#state_edit').on('change', function (ev) {
    var stateId = jQuery(this).val();
    if (stateId != '') {
      locationInfoEditInstance.getCities(stateId, null);
    } else {
      jQuery('#city_edit option:gt(0)').remove();
    }
  });
});
